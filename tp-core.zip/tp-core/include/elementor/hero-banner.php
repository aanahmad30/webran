<?php
namespace TPCore\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Group_Control_Background;
use \Elementor\Control_Media;
use \Elementor\Utils;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Tp Core
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class TP_Hero_Banner extends Widget_Base {

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'hero-banner';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Hero Banner', 'tpcore' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'tp-icon';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'tpcore' ];
	}

	/**
	 * Retrieve the list of scripts the widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends() {
		return [ 'tpcore' ];
	}

	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function register_controls() {

        // layout Panel
        $this->start_controls_section(
            'tp_layout',
            [
                'label' => esc_html__('Design Layout', 'tpcore'),
            ]
        );
        $this->add_control(
            'tp_design_style',
            [
                'label' => esc_html__('Select Layout', 'tpcore'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'layout-1' => esc_html__('Layout 1', 'tpcore'),
                    'layout-2' => esc_html__('Layout 2', 'tpcore'),
                    'layout-3' => esc_html__('Layout 3', 'tpcore'),
                ],
                'default' => 'layout-1',
            ]
        );

        $this->end_controls_section();

        // tp_section_title
        $this->start_controls_section(
            'tp_section_title',
            [
                'label' => esc_html__('Title & Content', 'tpcore'),
            ]
        );
        
        $this->add_control(
            'tp_sub_title',
            [
                'label' => esc_html__('Sub Title', 'tpcore'),
                'description' => tp_get_allowed_html_desc( 'basic' ),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('TP Sub Title', 'tpcore'),
                'placeholder' => esc_html__('Type Sub Heading Text', 'tpcore'),
                'label_block' => true,
                'condition' => ['tp_design_style' => ['layout-1', 'layout-3']]
            ]
        );
        $this->add_control(
            'tp_title',
            [
                'label' => esc_html__('Title', 'tpcore'),
                'description' => tp_get_allowed_html_desc( 'intermediate' ),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('TP Title Here', 'tpcore'),
                'placeholder' => esc_html__('Type Heading Text', 'tpcore'),
                'label_block' => true,
            ]
        );

        $this->add_control(
            'tp_head_image',
            [
                'label' => esc_html__( 'Choose Image', 'tpcore' ),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],
                'condition' => ['tp_design_style' => 'layout-2']
            ]
        );

        $this->add_control(
            'tp_desctiption',
            [
                'label' => esc_html__('Description', 'tpcore'),
                'description' => tp_get_allowed_html_desc( 'intermediate' ),
                'type' => Controls_Manager::TEXTAREA,
                'default' => esc_html__('TP section description here', 'tpcore'),
                'placeholder' => esc_html__('Type section description here', 'tpcore'),
            ]
        );

        $this->add_control(
            'tp_title_tag',
            [
                'label' => esc_html__('Title HTML Tag', 'tpcore'),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'h1' => [
                        'title' => esc_html__('H1', 'tpcore'),
                        'icon' => 'eicon-editor-h1'
                    ],
                    'h2' => [
                        'title' => esc_html__('H2', 'tpcore'),
                        'icon' => 'eicon-editor-h2'
                    ],
                    'h3' => [
                        'title' => esc_html__('H3', 'tpcore'),
                        'icon' => 'eicon-editor-h3'
                    ],
                    'h4' => [
                        'title' => esc_html__('H4', 'tpcore'),
                        'icon' => 'eicon-editor-h4'
                    ],
                    'h5' => [
                        'title' => esc_html__('H5', 'tpcore'),
                        'icon' => 'eicon-editor-h5'
                    ],
                    'h6' => [
                        'title' => esc_html__('H6', 'tpcore'),
                        'icon' => 'eicon-editor-h6'
                    ]
                ],
                'default' => 'h2',
                'toggle' => false,
            ]
        );

        $this->add_responsive_control(
            'tp_align',
            [
                'label' => esc_html__('Alignment', 'tpcore'),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                        'title' => esc_html__('Left', 'tpcore'),
                        'icon' => 'eicon-text-align-left',
                    ],
                    'center' => [
                        'title' => esc_html__('Center', 'tpcore'),
                        'icon' => 'eicon-text-align-center',
                    ],
                    'right' => [
                        'title' => esc_html__('Right', 'tpcore'),
                        'icon' => 'eicon-text-align-right',
                    ],
                ],
                'default' => 'left',
                'toggle' => true,
                'selectors' => [
                    '{{WRAPPER}} .tp-hero__section-box' => 'text-align: {{VALUE}};',
                ],
                'condition' => ['tp_design_style' => 'layout-1']
            ]
        );
        $this->end_controls_section();

        // tp_btn_button_group
        $this->start_controls_section(
            'tp_btn_button_group',
            [
                'label' => esc_html__('Button', 'tpcore'),
                'condition' => ['tp_design_style' => ['layout-1', 'layout-3']]
            ]
        );

        $this->add_control(
            'tp_btn_button_show',
            [
                'label' => esc_html__( 'Show Button', 'tpcore' ),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'Show', 'tpcore' ),
                'label_off' => esc_html__( 'Hide', 'tpcore' ),
                'return_value' => 'yes',
                'default' => true,
            ]
        );

        $this->add_control(
            'tp_btn_text',
            [
                'label' => esc_html__('Button Text', 'tpcore'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Button Text', 'tpcore'),
                'title' => esc_html__('Enter button text', 'tpcore'),
                'label_block' => true,
                'condition' => [
                    'tp_btn_button_show' => 'yes'
                ],
            ]
        );
        $this->add_control(
            'tp_btn_link_type',
            [
                'label' => esc_html__('Button Link Type', 'tpcore'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    '1' => 'Custom Link',
                    '2' => 'Internal Page',
                ],
                'default' => '1',
                'label_block' => true,
                'condition' => [
                    'tp_btn_button_show' => 'yes'
                ],
            ]
        );
        $this->add_control(
            'tp_btn_link',
            [
                'label' => esc_html__('Button link', 'tpcore'),
                'type' => Controls_Manager::URL,
                'dynamic' => [
                    'active' => true,
                ],
                'placeholder' => esc_html__('https://your-link.com', 'tpcore'),
                'show_external' => false,
                'default' => [
                    'url' => '#',
                    'is_external' => true,
                    'nofollow' => true,
                    'custom_attributes' => '',
                ],
                'condition' => [
                    'tp_btn_link_type' => '1',
                    'tp_btn_button_show' => 'yes'
                ],
                'label_block' => true,
            ]
        );
        $this->add_control(
            'tp_btn_page_link',
            [
                'label' => esc_html__('Select Button Page', 'tpcore'),
                'type' => Controls_Manager::SELECT2,
                'label_block' => true,
                'options' => tp_get_all_pages(),
                'condition' => [
                    'tp_btn_link_type' => '2',
                    'tp_btn_button_show' => 'yes'
                ]
            ]
        );

        

        $this->add_control(
            'tp_btn_button_show_2',
            [
                'label' => esc_html__( 'Show Button 2', 'tpcore' ),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'Show', 'tpcore' ),
                'label_off' => esc_html__( 'Hide', 'tpcore' ),
                'return_value' => 'yes',
                'default' => true,
            ]
        );

        $this->add_control(
            'tp_btn_text_2',
            [
                'label' => esc_html__('Button Text 2', 'tpcore'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Button Text 2', 'tpcore'),
                'title' => esc_html__('Enter button text 2', 'tpcore'),
                'label_block' => true,
                'condition' => [
                    'tp_btn_button_show_2' => 'yes'
                ],
            ]
        );
        $this->add_control(
            'tp_btn_link_type_2',
            [
                'label' => esc_html__('Button Link Type 2', 'tpcore'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    '1' => 'Custom Link',
                    '2' => 'Internal Page',
                ],
                'default' => '1',
                'label_block' => true,
                'condition' => [
                    'tp_btn_button_show_2' => 'yes'
                ],
            ]
        );
        $this->add_control(
            'tp_btn_link_2',
            [
                'label' => esc_html__('Button link 2', 'tpcore'),
                'type' => Controls_Manager::URL,
                'dynamic' => [
                    'active' => true,
                ],
                'placeholder' => esc_html__('https://your-link.com', 'tpcore'),
                'show_external' => false,
                'default' => [
                    'url' => '#',
                    'is_external' => true,
                    'nofollow' => true,
                    'custom_attributes' => '',
                ],
                'condition' => [
                    'tp_btn_link_type_2' => '1',
                    'tp_btn_button_show_2' => 'yes'
                ],
                'label_block' => true,
            ]
        );
        $this->add_control(
            'tp_btn_page_link_2',
            [
                'label' => esc_html__('Select Button Page 2', 'tpcore'),
                'type' => Controls_Manager::SELECT2,
                'label_block' => true,
                'options' => tp_get_all_pages(),
                'condition' => [
                    'tp_btn_link_type_2' => '2',
                    'tp_btn_button_show_2' => 'yes'
                ]
            ]
        );
        $this->end_controls_section();


        // _tp_image
        $this->start_controls_section(
            '_tp_image_section',
            [
                'label' => esc_html__('Thumbnail', 'tpcore'),
            ]
        );
        $this->add_control(
            'tp_image',
            [
                'label' => esc_html__( 'Choose Image', 'tpcore' ),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],
                'condition' => ['tp_design_style' => ['layout-1', 'layout-3']]
            ]
        );
        $this->add_control(
            'bg_image',
            [
                'label' => esc_html__( 'Choose BG Image', 'tpcore' ),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],
                'condition' => ['tp_design_style' => ['layout-1', 'layout-2']]
            ]
        );
        $this->add_group_control(
            Group_Control_Image_Size::get_type(),
            [
                'name' => 'tp_image_size',
                'default' => 'full',
                'exclude' => [
                    'custom'
                ]
            ]
        );
        $this->end_controls_section();

        // _tp_shape
        $this->start_controls_section(
            '_tp_shape_section',
            [
                'label' => esc_html__('Shape', 'tpcore'),
            ]
        );

        $this->add_control(
            'tp_shape_show',
            [
                'label' => esc_html__( 'Section Shape Show', 'tpcore' ),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'Show', 'tpcore' ),
                'label_off' => esc_html__( 'Hide', 'tpcore' ),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'cursor_url',
            [
                'label' => __('Cursor Url', 'tpcore'),
                'label_block' => true,
                'type' => Controls_Manager::TEXT,
                'default' => __('#', 'tpcore'),
                'placeholder' => __('Type url here', 'tpcore'),
                'dynamic' => [
                    'active' => true,
                ],
                'condition' => [
                    'tp_design_style' => 'layout-2',
                    'tp_shape_show' => 'yes'
                ]
            ]
        );

        $this->end_controls_section();

        // _section_exp_info
        $this->start_controls_section(
            '_section_exp_info',
            [
                'label' => __('Experience Info', 'tpcore'),
                'tab' => Controls_Manager::TAB_CONTENT,
                'condition' => ['tp_design_style' => 'layout-1']
            ]
        );

        $this->add_control(
            'exp_title',
            [
                'label' => __('Title', 'tpcore'),
                'label_block' => true,
                'type' => Controls_Manager::TEXT,
                'default' => __('Experience Title', 'tpcore'),
                'placeholder' => __('Type title Here', 'tpcore'),
                'dynamic' => [
                    'active' => true,
                ]
            ]
        );

        $this->add_control(
            'exp_des',
            [
                'label' => __('Description', 'tpcore'),
                'label_block' => true,
                'type' => Controls_Manager::TEXTAREA,
                'default' => __('Experience Description', 'tpcore'),
                'placeholder' => __('Type Description Here', 'tpcore'),
                'dynamic' => [
                    'active' => true,
                ]
            ]
        );

        
        $this->add_control(
            'ex_image',
            [
                'label' => esc_html__( 'Choose Image', 'tpcore' ),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],
            ]
        );

        $this->add_control(
            'exp_name',
            [
                'label' => __('Name', 'tpcore'),
                'label_block' => true,
                'type' => Controls_Manager::TEXT,
                'default' => __('Jone Smith', 'tpcore'),
                'placeholder' => __('Type name Here', 'tpcore'),
                'dynamic' => [
                    'active' => true,
                ]
            ]
        );

        $this->add_control(
            'exp_desig',
            [
                'label' => __('Designation', 'tpcore'),
                'label_block' => true,
                'type' => Controls_Manager::TEXT,
                'default' => __('Founder', 'tpcore'),
                'placeholder' => __('Type designation here', 'tpcore'),
                'dynamic' => [
                    'active' => true,
                ]
            ]
        );

        $this->end_controls_section();

        // Service group
        $this->start_controls_section(
            'tp_services',
            [
                'label' => esc_html__('Services List', 'tpcore'),
                'description' => esc_html__( 'Control all the style settings from Style tab', 'tpcore' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
                'condition' => ['tp_design_style' => ['layout-1', 'layout-2']]
            ]
        );

        $repeater = new \Elementor\Repeater();

        $repeater->add_control(
            'repeater_condition',
            [
                'label' => __( 'Field condition', 'tpcore' ),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'style_1' => __( 'Style 1', 'tpcore' ),
                    'style_2' => __( 'Style 2', 'tpcore' ),
                ],
                'default' => 'style_1',
                'frontend_available' => true,
                'style_transfer' => true,
            ]
        );

        $repeater->add_control(
            'tp_service_icon_type',
            [
                'label' => esc_html__('Select Icon Type', 'tpcore'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'icon',
                'options' => [
                    'image' => esc_html__('Image', 'tpcore'),
                    'icon' => esc_html__('Icon', 'tpcore'),
                    'svg' => esc_html__('SVG', 'tpcore'),
                ],
                'condition' => ['repeater_condition' => 'style_1']
            ]
        );

        $repeater->add_control(
            'tp_service_image',
            [
                'label' => esc_html__('Upload Icon Image', 'tpcore'),
                'type' => Controls_Manager::MEDIA,
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
                'condition' => [
                    'tp_service_icon_type' => 'image',
                    'repeater_condition' => 'style_1'
                ]

            ]
        );

        if (tp_is_elementor_version('<', '2.6.0')) {
            $repeater->add_control(
                'tp_service_icon',
                [
                    'show_label' => false,
                    'type' => Controls_Manager::ICON,
                    'label_block' => true,
                    'default' => 'fa fa-star',
                    'condition' => [
                        'tp_service_icon_type' => 'icon',
                        'repeater_condition' => 'style_1'
                    ]
                ]
            );
        } else {
            $repeater->add_control(
                'tp_service_selected_icon',
                [
                    'show_label' => false,
                    'type' => Controls_Manager::ICONS,
                    'fa4compatibility' => 'icon',
                    'label_block' => true,
                    'default' => [
                        'value' => 'fas fa-star',
                        'library' => 'solid',
                    ],
                    'condition' => [
                        'tp_service_icon_type' => 'icon',
                        'repeater_condition' => 'style_1'
                    ]
                ]
            );
        }

        $repeater->add_control(
            'tp_service_icon_svg',
            [
                'show_label' => false,
                'type' => Controls_Manager::TEXTAREA,
                'label_block' => true,
                'placeholder' => esc_html__('SVG Code Here', 'tp-core'),
                'condition' => [
                    'tp_service_icon_type' => 'svg',
                    'repeater_condition' => 'style_1'
                ]
            ]
        );


        $repeater->add_control(
            'tp_service_title', [
                'label' => esc_html__('Title', 'tpcore'),
                'description' => tp_get_allowed_html_desc( 'basic' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__('Service Title', 'tpcore'),
                'label_block' => true,
            ]
        );

        $repeater->add_control(
            'tp_service_description',
            [
                'label' => esc_html__('Description', 'tpcore'),
                'description' => tp_get_allowed_html_desc( 'intermediate' ),
                'type' => \Elementor\Controls_Manager::TEXTAREA,
                'default' => 'There are many variations of passages of Lorem Ipsum available, but the majority have suffered.',
                'label_block' => true,
                'condition' => [
                    'repeater_condition' => 'style_1'
                ]
            ]
        );

        $repeater->add_control(
            'tp_services_link_switcher',
            [
                'label' => esc_html__( 'Add Services link', 'tpcore' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'Yes', 'tpcore' ),
                'label_off' => esc_html__( 'No', 'tpcore' ),
                'return_value' => 'yes',
                'default' => 'yes',
                'separator' => 'before',
            ]
        );
        $repeater->add_control(
            'tp_services_btn_text',
            [
                'label' => esc_html__('Button Text', 'tpcore'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Button Text', 'tpcore'),
                'title' => esc_html__('Enter button text', 'tpcore'),
                'label_block' => true,
                'condition' => [
                    'tp_services_link_switcher' => 'yes',
                ],
            ]
        );
        $repeater->add_control(
            'tp_services_link_type',
            [
                'label' => esc_html__( 'Service Link Type', 'tpcore' ),
                'type' => \Elementor\Controls_Manager::SELECT,
                'options' => [
                    '1' => 'Custom Link',
                    '2' => 'Internal Page',
                ],
                'default' => '1',
                'condition' => [
                    'tp_services_link_switcher' => 'yes'
                ]
            ]
        );
        $repeater->add_control(
            'tp_services_link',
            [
                'label' => esc_html__( 'Service Link link', 'tpcore' ),
                'type' => \Elementor\Controls_Manager::URL,
                'dynamic' => [
                    'active' => true,
                ],
                'placeholder' => esc_html__( 'https://your-link.com', 'tpcore' ),
                'show_external' => true,
                'default' => [
                    'url' => '#',
                    'is_external' => false,
                    'nofollow' => false,
                ],
                'condition' => [
                    'tp_services_link_type' => '1',
                    'tp_services_link_switcher' => 'yes',
                ]
            ]
        );
        $repeater->add_control(
            'tp_services_page_link',
            [
                'label' => esc_html__( 'Select Service Link Page', 'tpcore' ),
                'type' => \Elementor\Controls_Manager::SELECT2,
                'label_block' => true,
                'options' => tp_get_all_pages(),
                'condition' => [
                    'tp_services_link_type' => '2',
                    'tp_services_link_switcher' => 'yes',
                ]
            ]
        );

        $repeater->add_control(
			'tp_creative_anima_switcher',
			[
				'label' => esc_html__( 'Active Animation', 'plugin-name' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'tpcore' ),
				'label_off' => esc_html__( 'No', 'tpcore' ),
				'return_value' => 'yes',
				'default' => 'yes',
                'separator' => 'before',
			]
		);

        $repeater->add_control(
            'animation_type',
            [
                'label' => __( 'Animation Type', 'tpcore' ),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'tpfadeLeft' => __( 'Fade Left', 'tpcore' ),
                    'tpfadeRight' => __( 'Fade Right', 'tpcore' ),
                    'tpfadeUp' => __( 'Fade Up', 'tpcore' ),
                    'tpfadeInDown' => __( 'Fade Down', 'tpcore' ),
                ],
                'default' => 'tpfadeUp',
                'frontend_available' => true,
                'style_transfer' => true,
                'condition' => ['tp_creative_anima_switcher' => 'yes']
            ]
        );
        
        $repeater->add_control(
            'tp_anima_dura', [
                'label' => esc_html__('Animation Duration', 'tpcore'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__('0.3s', 'tpcore'),
                'condition' => ['tp_creative_anima_switcher' => 'yes']
            ]
        );
        
        $repeater->add_control(
            'tp_anima_delay', [
                'label' => esc_html__('Animation Delay', 'tpcore'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__('0.6s', 'tpcore'),
                'condition' => ['tp_creative_anima_switcher' => 'yes']
            ]
        ); 
        
        $repeater->add_control(
            'want_customize',
            [
                'label' => esc_html__( 'Want To Customize?', 'tpcore' ),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'Yes', 'tpcore' ),
                'label_off' => esc_html__( 'No', 'tpcore' ),
                'return_value' => 'yes',
                'description' => esc_html__( 'You can customize this skill bar color from here or customize from Style tab', 'tpcore' ),
                'style_transfer' => true,
            ]
        );

        // customization tab start
        $repeater->start_controls_tabs(
            'customization_tabs',
            [
                'condition' => [
                    'want_customize' => 'yes',
                    'repeater_condition' => 'style_1',
                ]
            ]
        );
        
        // normal tab start
        $repeater->start_controls_tab(
            'customization_normal_tab',
            [
                'label' => esc_html__( 'Normal', 'textdomain' ),
            ]
        );

        $repeater->add_control(
            'icon_color',
            [
                'label' => esc_html__( 'Icon Color', 'tpcore' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} {{CURRENT_ITEM}} .tp-slider-exp-item__icon svg, {{WRAPPER}} {{CURRENT_ITEM}} .tp-slider-exp-item__icon i' => 'color: {{VALUE}};',
                ],
                'condition' => [
                    'want_customize' => 'yes',
                ],
                'style_transfer' => true,
            ]
        ); 

        $repeater->add_control(
            'icon_bg_color',
            [
                'label' => esc_html__( 'Icon BG Color', 'tpcore' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} {{CURRENT_ITEM}} .tp-slider-exp-item__icon' => 'background-color: {{VALUE}};',
                ],
                'condition' => [
                    'want_customize' => 'yes',
                ],
                'style_transfer' => true,
            ]
        ); 

        $repeater->add_control(
            'btn_shape_color',
            [
                'label' => esc_html__( 'Button Shape Color', 'tpcore' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} {{CURRENT_ITEM}} .tp-link-green a::after' => 'background-color: {{VALUE}};',
                ],
                'condition' => [
                    'want_customize' => 'yes',
                ],
                'style_transfer' => true,
            ]
        ); 

        $repeater->add_control(
            'btn_color',
            [
                'label' => esc_html__( 'Button Color', 'tpcore' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} {{CURRENT_ITEM}} .tp-link a span' => 'color: {{VALUE}};',
                ],
                'condition' => [
                    'want_customize' => 'yes',
                ],
                'style_transfer' => true,
            ]
        ); 
        
        $repeater->end_controls_tab();
        // normal tab end
        
        // hover tab start
        $repeater->start_controls_tab(
            'customization_hover_tab',
            [
                'label' => esc_html__( 'Hover', 'textdomain' ),
            ]
        );

        $repeater->add_control(
            'btn_shover_color',
            [
                'label' => esc_html__( 'Button Shape Hover Color', 'tpcore' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} {{CURRENT_ITEM}} .tp-link-green a::before' => 'background-color: {{VALUE}};',
                ],
                'condition' => [
                    'want_customize' => 'yes',
                ],
                'style_transfer' => true,
            ]
        );

        $repeater->add_control(
            'btn_hover_color',
            [
                'label' => esc_html__( 'Button Hover Color', 'tpcore' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} {{CURRENT_ITEM}} .tp-link-green a:hover span' => 'color: {{VALUE}};',
                ],
                'condition' => [
                    'want_customize' => 'yes',
                ],
                'style_transfer' => true,
            ]
        );
        
        $repeater->end_controls_tab();
        // hover tab end
        
        $repeater->end_controls_tabs();
        // customization tab end

        // customization tab start 2
        $repeater->start_controls_tabs(
            'customization_tabs_2',
            [
                'condition' => [
                    'want_customize' => 'yes',
                    'repeater_condition' => 'style_2',
                ]
            ]
        );
        
        // normal tab start 2
        $repeater->start_controls_tab(
            'customization_normal_tab_2',
            [
                'label' => esc_html__( 'Normal', 'textdomain' ),
            ]
        );

        $repeater->add_control(
            'border_color',
            [
                'label' => esc_html__( 'Border Color', 'tpcore' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} {{CURRENT_ITEM}}.tp-cta-item' => 'border-color: {{VALUE}};',
                ],
                'condition' => [
                    'want_customize' => 'yes',
                ],
                'style_transfer' => true,
            ]
        ); 

        $repeater->add_control(
            'btn_color_2',
            [
                'label' => esc_html__( 'Button Color', 'tpcore' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} {{CURRENT_ITEM}} .tp-btn-green' => 'color: {{VALUE}};',
                ],
                'condition' => [
                    'want_customize' => 'yes',
                ],
                'style_transfer' => true,
            ]
        ); 

        $repeater->add_control(
            'btn_bg_color_2',
            [
                'label' => esc_html__( 'Button Background', 'tpcore' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} {{CURRENT_ITEM}} .tp-btn-green' => 'background-color: {{VALUE}};',
                ],
                'condition' => [
                    'want_customize' => 'yes',
                ],
                'style_transfer' => true,
            ]
        ); 
        
        $repeater->end_controls_tab();
        // normal tab end 2
        
        // hover tab start 2
        $repeater->start_controls_tab(
            'customization_hover_tab_2',
            [
                'label' => esc_html__( 'Hover', 'textdomain' ),
            ]
        );

        $repeater->add_control(
            'btn_hover_color_2',
            [
                'label' => esc_html__( 'Button Color', 'tpcore' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} {{CURRENT_ITEM}} .tp-btn-green:hover' => 'color: {{VALUE}};',
                ],
                'condition' => [
                    'want_customize' => 'yes',
                ],
                'style_transfer' => true,
            ]
        );

        $repeater->add_control(
            'btn_hover_bg_2',
            [
                'label' => esc_html__( 'Button Background', 'tpcore' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} {{CURRENT_ITEM}} .tp-btn-green:hover' => 'background-color: {{VALUE}};',
                ],
                'condition' => [
                    'want_customize' => 'yes',
                ],
                'style_transfer' => true,
            ]
        );
        
        $repeater->end_controls_tab();
        // hover tab end 2
        
        $repeater->end_controls_tabs();
        // customization tab end 2

        $this->add_control(
            'tp_service_list',
            [
                'label' => esc_html__('Services - List', 'tpcore'),
                'type' => \Elementor\Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'default' => [
                    [
                        'tp_service_title' => esc_html__('Business Stratagy', 'tpcore'),
                    ],
                    [
                        'tp_service_title' => esc_html__('Website Development', 'tpcore')
                    ],
                    [
                        'tp_service_title' => esc_html__('Marketing & Reporting', 'tpcore')
                    ]
                ],
                'title_field' => '{{{ tp_service_title }}}',
            ]
        );

        $this->add_control(
            'shadow_style',
            [
                'label' => __( 'Shadow', 'tpcore' ),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'service-default' => __( 'Style 1', 'tpcore' ),
                    'sv-1-border' => __( 'Style 2', 'tpcore' ),
                ],
                'default' => 'service-default',
                'frontend_available' => true,
                'style_transfer' => true,
                'condition' => ['tp_design_style' => 'layout-4']
            ]
        );
        $this->end_controls_section();

        // _section_review_info
        $this->start_controls_section(
            '_section_review_info',
            [
                'label' => __('Review', 'tpcore'),
                'tab' => Controls_Manager::TAB_CONTENT,
                'condition' => ['tp_design_style' => 'layout-3']
            ]
        );

        $this->add_control(
            'review_text_1',
            [
                'label' => __('Review Text 1', 'tpcore'),
                'label_block' => true,
                'type' => Controls_Manager::TEXTAREA,
                'default' => __('Review Text 1 Here', 'tpcore'),
                'placeholder' => __('Type review here', 'tpcore'),
                'dynamic' => [
                    'active' => true,
                ]
            ]
        );

        $this->add_control(
            'review_text_2',
            [
                'label' => __('Review Text 2', 'tpcore'),
                'label_block' => true,
                'type' => Controls_Manager::TEXTAREA,
                'default' => __('Review Text 2 Here', 'tpcore'),
                'placeholder' => __('Type review here', 'tpcore'),
                'dynamic' => [
                    'active' => true,
                ]
            ]
        );

        $this->end_controls_section();


		// TAB_STYLE
		$this->start_controls_section(
			'section_style',
			[
				'label' => __( 'Style', 'tpcore' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'text_transform',
			[
				'label' => __( 'Text Transform', 'tpcore' ),
				'type' => Controls_Manager::SELECT,
				'default' => '',
				'options' => [
					'' => __( 'None', 'tpcore' ),
					'uppercase' => __( 'UPPERCASE', 'tpcore' ),
					'lowercase' => __( 'lowercase', 'tpcore' ),
					'capitalize' => __( 'Capitalize', 'tpcore' ),
				],
				'selectors' => [
					'{{WRAPPER}} .title' => 'text-transform: {{VALUE}};',
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Render the widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();


		if ( $settings['tp_design_style']  == 'layout-2' ): 
            if ( !empty($settings['bg_image']['url']) ) {
                $bg_image = !empty($settings['bg_image']['id']) ? wp_get_attachment_image_url( $settings['bg_image']['id'], $settings['tp_image_size_size']) : $settings['bg_image']['url'];
                $bg_image_alt = get_post_meta($settings["bg_image"]["id"], "_wp_attachment_image_alt", true);
            }

            $head_image = $settings['tp_head_image']['url'];

            $this->add_render_attribute('title_args', 'class', 'tp-slider-title text-white');
        ?>

<?php if(!empty($bg_image)) : ?>
<div class="tp-hero-area hero-bg-img hero-overlay" style="background-image: url(<?php echo esc_url($bg_image); ?>); ">
    <?php else : ?>
    <div class="tp-hero-area hero-bg-img hero-overlay">
        <?php endif; ?>

        <div class="container z-index-3">
            <div class="row align-items-center">
                <div class="col-xl-12 wow tpfadeUp" data-wow-duration=".7s" data-wow-delay=".5s">
                    <div class="hero-section-title-box text-center">
                        <?php
                    if ( !empty($settings['tp_title' ]) ) :
                        printf( '<%1$s %2$s>%3$s</%1$s>',
                            tag_escape( $settings['tp_title_tag'] ),
                            $this->get_render_attribute_string( 'title_args' ),
                            tp_kses( $settings['tp_title' ] )
                            );
                    endif;
                    ?>
                    </div>
                </div>
            </div>
            <div class="row justify-content-center align-items-center hero-thumb-space wow tpfadeUp"
                data-wow-duration=".7s" data-wow-delay=".8s">
                <?php if(!empty($head_image)) : ?>
                <div class="col-xl-6 col-lg-6 col-md-12">
                    <div class="tp-hero-content">
                        <div class="tp-hero-content__thumb text-center text-lg-end">
                            <img src="<?php echo esc_url($head_image); ?>"
                                alt="<?php echo esc_attr__('head-img', 'tpcore'); ?>">
                        </div>
                    </div>
                </div>
                <?php endif; ?>
                <?php if ( !empty($settings['tp_desctiption']) ) : ?>
                <div class="col-xl-6 col-lg-6 col-md-6 col-12">
                    <div class="tp-hero-content__text text-center text-lg-start">
                        <p class="mb-0"><?php echo tp_kses($settings['tp_desctiption']); ?></p>
                    </div>
                </div>
                <?php endif; ?>
            </div>
            <?php if(!empty($settings['tp_shape_show'])) : ?>
            <div class="row">
                <div class="col-12 smooth wow tpfadeUp" data-wow-duration=".7s" data-wow-delay="1s">
                    <a href="<?php echo esc_attr($settings['cursor_url']); ?>">
                        <div class="scroll-down text-center mb-70">
                            <div class="scroll-dots d-flex justify-content-center flex-column align-items-center">
                                <span class="circle-1"></span>
                                <span class="circle-2"></span>
                                <span class="circle-3"></span>
                            </div>
                            <span><i class="fal fa-mouse"></i></span>
                        </div>
                    </a>
                </div>
            </div>
            <?php endif; ?>
            <div class="tp-cta-wrapper d-flex justify-content-center">
                <div class="row g-0">

                    <?php foreach ($settings['tp_service_list'] as $key => $item) : 
                    $border_none = ($key == 2) ? '' : 'features__border-right';
                    // Link
                    if ('2' == $item['tp_services_link_type']) {
                        $link = get_permalink($item['tp_services_page_link']);
                        $target = '_self';
                        $rel = 'nofollow';
                    } else {
                        $link = !empty($item['tp_services_link']['url']) ? $item['tp_services_link']['url'] : '';
                        $target = !empty($item['tp_services_link']['is_external']) ? '_blank' : '';
                        $rel = !empty($item['tp_services_link']['nofollow']) ? 'nofollow' : '';
                    }
                ?>
                    <?php if(!empty($item['tp_creative_anima_switcher'])) : ?>
                    <div class="col-lg-6 col-md-6 col-sm-6 mb-30 wow <?php echo esc_attr($item['animation_type']); ?>"
                        data-wow-duration="<?php echo esc_attr($item['tp_anima_dura']);?>"
                        data-wow-delay="<?php echo esc_attr($item['tp_anima_delay']);?>">
                        <?php else : ?>
                        <div class="col-lg-6 col-md-6 col-sm-6 mb-30">
                            <?php endif; ?>
                            <div class="tp-cta-item elementor-repeater-item-<?php echo esc_attr($item['_id']); ?>">
                                <div class="tp-cta-info">
                                    <?php if(!empty($item['tp_service_title' ])): ?>
                                    <h3 class="tp-cta-title"><?php echo tp_kses($item['tp_service_title' ]); ?></h3>
                                    <?php endif; ?>
                                    <?php if(!empty($item['tp_services_btn_text'])) : ?>
                                    <a class="tp-btn-green" href="<?php echo esc_url($link); ?>"
                                        target="<?php echo esc_attr($target); ?>"
                                        rel="<?php echo esc_attr($rel); ?>"><?php echo tp_kses($item['tp_services_btn_text']); ?></a>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; ?>

                    </div>
                </div>
            </div>
        </div>

        <?php elseif ( $settings['tp_design_style']  == 'layout-3' ): 
            if ( !empty($settings['tp_image']['url']) ) {
                $tp_image = !empty($settings['tp_image']['id']) ? wp_get_attachment_image_url( $settings['tp_image']['id'], $settings['tp_image_size_size']) : $settings['tp_image']['url'];
                $tp_image_alt = get_post_meta($settings["tp_image"]["id"], "_wp_attachment_image_alt", true);
            }

            // Link
            if ('2' == $settings['tp_btn_link_type']) {
                $this->add_render_attribute('tp-button-arg', 'href', get_permalink($settings['tp_btn_page_link']));
                $this->add_render_attribute('tp-button-arg', 'target', '_self');
                $this->add_render_attribute('tp-button-arg', 'rel', 'nofollow');
                $this->add_render_attribute('tp-button-arg', 'class', 'tp-btn');
            } else {
                if ( ! empty( $settings['tp_btn_link']['url'] ) ) {
                    $this->add_link_attributes( 'tp-button-arg', $settings['tp_btn_link'] );
                    $this->add_render_attribute('tp-button-arg', 'class', 'tp-btn');
                }
            }

            // Link
            if ('2' == $settings['tp_btn_link_type_2']) {
                $this->add_render_attribute('tp-button-arg_2', 'href', get_permalink($settings['tp_btn_page_link_2']));
                $this->add_render_attribute('tp-button-arg_2', 'target', '_self');
                $this->add_render_attribute('tp-button-arg_2', 'rel', 'nofollow');
                $this->add_render_attribute('tp-button-arg_2', 'class', 'popup-video');
            } else {
                if ( ! empty( $settings['tp_btn_link_2']['url'] ) ) {
                    $this->add_link_attributes( 'tp-button-arg_2', $settings['tp_btn_link_2'] );
                    $this->add_render_attribute('tp-button-arg_2', 'class', 'popup-video');
                }
            }

            $this->add_render_attribute('title_args', 'class', 'tp-slider-sm-title mb-40 wow tpfadeUp');
            $this->add_render_attribute('title_args', 'data-wow-duration', '.7s');
            $this->add_render_attribute('title_args', 'data-wow-delay', '.8s');
        ?>

        <div class="tp-hero-area hero-space-three">
            <div class="tp-hero-blue-shape d-none d-lg-block"></div>
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-xxl-5 col-xl-6 col-lg-5">
                        <div class="tp-hero">
                            <div class="tp-hero__section-box mb-30">
                                <?php if ( !empty($settings['tp_sub_title']) ) : ?>
                                    <h4 class="tp-section-subtitle wow tpfadeUp" data-wow-duration=".7s"
                                    data-wow-delay=".5s"><?php echo tp_kses( $settings['tp_sub_title'] ); ?></h4>
                                <?php endif; ?>
                                <?php
                                if ( !empty($settings['tp_title' ]) ) :
                                    printf( '<%1$s %2$s>%3$s</%1$s>',
                                        tag_escape( $settings['tp_title_tag'] ),
                                        $this->get_render_attribute_string( 'title_args' ),
                                        tp_kses( $settings['tp_title' ] )
                                        );
                                endif;
                                ?>
                                <?php if ( !empty($settings['tp_desctiption']) ) : ?>
                                <p class="wow tpfadeUp" data-wow-duration=".7s" data-wow-delay=".8s">
                                    <?php echo tp_kses( $settings['tp_desctiption'] ); ?></p>
                                <?php endif; ?>
                            </div>
                            <div class="tp-hero__wrapper d-flex align-items-center wow tpfadeUp" data-wow-duration=".7s"
                                data-wow-delay=".9s">
                                <?php if (!empty($settings['tp_btn_text'])) : ?>
                                <div class="tp-hero__button">
                                    <a <?php echo $this->get_render_attribute_string( 'tp-button-arg' ); ?>><?php echo tp_kses($settings['tp_btn_text']); ?></a>
                                </div>
                                <?php endif; ?>
                                <?php if (!empty($settings['tp_btn_text_2'])) : ?>
                                <div class="tp-hero__play-button">
                                    <a <?php echo $this->get_render_attribute_string( 'tp-button-arg_2' ); ?>><i
                                            class="fas fa-play"></i></a>
                                    <span><?php echo tp_kses($settings['tp_btn_text_2']); ?></span>
                                </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <div class="col-xxl-7 col-xl-6 col-lg-7">
                        <div class="tp-hero d-flex justify-content-end">
                            <div class="tp-hero__thumb3 p-relative">

                                <?php if(!empty($tp_image)) : ?>
                                <img class="wow tpfadeRight" data-wow-duration=".7s" data-wow-delay=".8s"
                                    src="<?php echo esc_url($tp_image); ?>" alt="<?php echo esc_attr($tp_image_alt); ?>">
                                <?php endif; ?>
                                <?php if(!empty($settings['tp_shape_show'])) : ?>
                                <div class="tp-hero__thumb3-shape-1">
                                    <img src="<?php echo get_template_directory_uri(); ?>/assets/img/slider/hero-shape-3-1.png" alt="">
                                </div>
                                <div class="tp-hero__thumb3-shape-2">
                                    <img src="<?php echo get_template_directory_uri(); ?>/assets/img/slider/hero-shape-3-3.png" alt="">
                                </div>
                                <?php endif; ?>

                                <?php if(!empty($settings['review_text_1'])) : ?>
                                <div class="review-wrapper d-none d-xl-block">
                                    <div class="review-box d-flex align-items-center">
                                        <?php echo tp_kses($settings['review_text_1']); ?>
                                    </div>
                                </div>
                                <?php endif; ?>

                                <?php if(!empty($settings['review_text_2'])) : ?>
                                <div class="review-wrapper-2 d-none d-xl-block">
                                    <div class="reviews-text">
                                        <?php echo tp_kses($settings['review_text_2']); ?>
                                    </div>
                                </div>
                                <?php endif; ?>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>



        <?php else: 
        if ( !empty($settings['tp_image']['url']) ) {
            $tp_image = !empty($settings['tp_image']['id']) ? wp_get_attachment_image_url( $settings['tp_image']['id'], $settings['tp_image_size_size']) : $settings['tp_image']['url'];
            $tp_image_alt = get_post_meta($settings["tp_image"]["id"], "_wp_attachment_image_alt", true);
        }

        if ( !empty($settings['bg_image']['url']) ) {
            $bg_image = !empty($settings['bg_image']['id']) ? wp_get_attachment_image_url( $settings['bg_image']['id'], $settings['tp_image_size_size']) : $settings['bg_image']['url'];
            $bg_image_alt = get_post_meta($settings["bg_image"]["id"], "_wp_attachment_image_alt", true);
        }

        // Link
        if ('2' == $settings['tp_btn_link_type']) {
            $this->add_render_attribute('tp-button-arg', 'href', get_permalink($settings['tp_btn_page_link']));
            $this->add_render_attribute('tp-button-arg', 'target', '_self');
            $this->add_render_attribute('tp-button-arg', 'rel', 'nofollow');
            $this->add_render_attribute('tp-button-arg', 'class', 'tp-btn');
        } else {
            if ( ! empty( $settings['tp_btn_link']['url'] ) ) {
                $this->add_link_attributes( 'tp-button-arg', $settings['tp_btn_link'] );
                $this->add_render_attribute('tp-button-arg', 'class', 'tp-btn');
            }
        }

        // Link
        if ('2' == $settings['tp_btn_link_type_2']) {
            $this->add_render_attribute('tp-button-arg_2', 'href', get_permalink($settings['tp_btn_page_link_2']));
            $this->add_render_attribute('tp-button-arg_2', 'target', '_self');
            $this->add_render_attribute('tp-button-arg_2', 'rel', 'nofollow');
            $this->add_render_attribute('tp-button-arg_2', 'class', 'popup-video');
        } else {
            if ( ! empty( $settings['tp_btn_link_2']['url'] ) ) {
                $this->add_link_attributes( 'tp-button-arg_2', $settings['tp_btn_link_2'] );
                $this->add_render_attribute('tp-button-arg_2', 'class', 'popup-video');
            }
        }
        
        $this->add_render_attribute('title_args', 'class', 'tp-slider-title wow tpfadeUp');
        $this->add_render_attribute('title_args', 'data-wow-duration', '.7s');
        $this->add_render_attribute('title_args', 'data-wow-delay', '.6s');

    ?>


        <?php if(!empty($bg_image)) : ?>
        <div class="tp-hero-area hero-grideant-bg" style="background-image: url(<?php echo esc_url($bg_image); ?>);">
            <?php else : ?>
            <div class="tp-hero-area hero-grideant-bg">
                <?php endif ; ?>
                <div class="container">
                    <div class="row align-items-center hero-space">
                        <div class="col-xl-6 col-lg-6">
                            <div class="tp-hero">
                                <div class="tp-hero__section-box">

                                    <?php if ( !empty($settings['tp_sub_title']) ) : ?>
                                    <h4 class="tp-section-subtitle  wow tpfadeUp" data-wow-duration=".7s"
                                        data-wow-delay=".3s"><?php echo tp_kses( $settings['tp_sub_title'] ); ?></h4>
                                    <?php endif; ?>

                                    <?php
                                    if ( !empty($settings['tp_title' ]) ) :
                                        printf( '<%1$s %2$s>%3$s</%1$s>',
                                            tag_escape( $settings['tp_title_tag'] ),
                                            $this->get_render_attribute_string( 'title_args' ),
                                            tp_kses( $settings['tp_title' ] )
                                            );
                                    endif;
                                    ?>

                                    <?php if ( !empty($settings['tp_desctiption']) ) : ?>
                                    <p class="wow tpfadeUp" data-wow-duration=".7s" data-wow-delay=".8s">
                                        <?php echo tp_kses( $settings['tp_desctiption'] ); ?></p>
                                    <?php endif; ?>

                                </div>

                                <div class="tp-hero__wrapper d-flex align-items-center wow tpfadeUp"
                                    data-wow-duration=".7s" data-wow-delay="1s">

                                    <?php if (!empty($settings['tp_btn_text'])) : ?>
                                    <div class="tp-hero__button">
                                        <a <?php echo $this->get_render_attribute_string( 'tp-button-arg' ); ?>><?php echo tp_kses($settings['tp_btn_text']); ?></a>
                                    </div>
                                    <?php endif; ?>

                                    <?php if(!empty($settings['tp_btn_text_2'])) : ?>
                                    <div class="tp-hero__play-button">
                                        <a <?php echo $this->get_render_attribute_string( 'tp-button-arg_2' ); ?>><i
                                                class="fas fa-play"></i></a>
                                        <span><?php echo tp_kses($settings['tp_btn_text_2']); ?></span>
                                    </div>
                                    <?php endif; ?>
                                </div>

                            </div>
                        </div>
                        <div class="col-xl-6 col-lg-6">
                            <div class="tp-hero__wrapper-thumb p-relative">
                                <?php if(!empty($settings['tp_shape_show'])) : ?>
                                <div class="tp-hero-shape-one">
                                    <img src="<?php echo get_template_directory_uri(); ?>/assets/img/slider/hero-star-shape.png "
                                        alt="">
                                </div>
                                <div class="tp-hero-shape-two">
                                    <img src="<?php echo get_template_directory_uri(); ?>/assets/img/slider/hero-circle-shape.png "
                                        alt="">
                                </div>
                                <div class="tp-hero-shape-three">
                                    <img src="<?php echo get_template_directory_uri(); ?>/assets/img/slider/hero-angel-shape.png "
                                        alt="">
                                </div>
                                <div class="tp-hero-shape-four">
                                    <img src="<?php echo get_template_directory_uri(); ?>/assets/img/slider/hero-star-sm-shape.png"
                                        alt="">
                                </div>
                                <?php endif; ?>
                                <?php if(!empty($tp_image)) : ?>
                                <div class="tp-hero__thumb text-start text-lg-end wow tpfadeRight"
                                    data-wow-duration=".9s" data-wow-delay="1.2s">
                                    <img src="<?php echo esc_url($tp_image); ?>"
                                        alt="<?php echo esc_attr($tp_image_alt); ?>">
                                </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-xl-5 col-lg-5 wow tpfadeUp" data-wow-duration=".7s" data-wow-delay=".3s">
                            <div class="tp-slider-exprience">
                                <div class="tp-slider-exprience__content">
                                    <?php if(!empty($settings['exp_title'])) : ?>
                                    <h4 class="tp-slider-exp-title"><?php echo tp_kses($settings['exp_title']); ?></h4>
                                    <?php endif; ?>
                                    <?php if(!empty($settings['exp_des'])) : ?>
                                    <p><?php echo tp_kses($settings['exp_des']); ?></p>
                                    <?php endif; ?>
                                </div>
                                <div class="tp-slider-exprience__client-info d-flex align-items-center">

                                    <?php if(!empty($settings['ex_image']['url'])) : ?>
                                    <div class="tp-slider-exprience__img">
                                        <img src="<?php echo esc_url($settings['ex_image']['url']); ?>"
                                            alt="<?php echo esc_html__('ex-img', 'tpcore'); ?>">
                                    </div>
                                    <?php endif; ?>
                                    <div class="tp-slider-exprience__meta">
                                        <?php if(!empty($settings['exp_name'])) : ?>
                                        <h5 class="tp-client-name"><?php echo tp_kses($settings['exp_name']); ?></h5>
                                        <?php endif; ?>
                                        <?php if(!empty($settings['exp_desig'])) : ?>
                                        <span><?php echo tp_kses($settings['exp_desig']); ?></span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-7 col-lg-7">
                            <div class="row">

                                <?php foreach ($settings['tp_service_list'] as $key => $item) : 
                        $border_none = ($key == 2) ? '' : 'features__border-right';
                        // Link
                        if ('2' == $item['tp_services_link_type']) {
                            $link = get_permalink($item['tp_services_page_link']);
                            $target = '_self';
                            $rel = 'nofollow';
                        } else {
                            $link = !empty($item['tp_services_link']['url']) ? $item['tp_services_link']['url'] : '';
                            $target = !empty($item['tp_services_link']['is_external']) ? '_blank' : '';
                            $rel = !empty($item['tp_services_link']['nofollow']) ? 'nofollow' : '';
                        }
                        ?>
                                <?php if(!empty($item['tp_creative_anima_switcher'])) : ?>
                                <div class="col-xl-6 col-lg-6 col-md-6 wow <?php echo esc_attr($item['animation_type']); ?>"
                                    data-wow-duration="<?php echo esc_attr($item['tp_anima_dura']);?>"
                                    data-wow-delay="<?php echo esc_attr($item['tp_anima_delay']);?>">
                                    <?php else : ?>
                                    <div class="col-xl-6 col-lg-6 col-md-6 ">
                                        <?php endif; ?>

                                        <div
                                            class="tp-slider-exp-item mb-30 elementor-repeater-item-<?php echo esc_attr($item['_id']); ?>">
                                            <?php if($item['tp_service_icon_type'] == 'icon') : ?>
                                            <?php if (!empty($item['tp_service_icon']) || !empty($item['tp_service_selected_icon']['value'])) : ?>
                                            <div class="tp-slider-exp-item__icon icon-bg-green">
                                                <?php tp_render_icon($item, 'tp_service_icon', 'tp_service_selected_icon'); ?>
                                            </div>
                                            <?php endif; ?>
                                            <?php elseif( $item['tp_service_icon_type'] == 'image' ) : ?>
                                            <?php if (!empty($item['tp_service_image']['url'])): ?>
                                            <div class="tp-slider-exp-item__icon icon-bg-green">
                                                <img class="light" src="<?php echo $item['tp_service_image']['url']; ?>"
                                                    alt="<?php echo get_post_meta(attachment_url_to_postid($item['tp_service_image']['url']), '_wp_attachment_image_alt', true); ?>">
                                            </div>
                                            <?php endif; ?>
                                            <?php else : ?>
                                            <?php if (!empty($item['tp_service_icon_svg'])): ?>
                                            <div class="tp-slider-exp-item__icon icon-bg-green">
                                                <?php echo $item['tp_service_icon_svg']; ?>
                                            </div>
                                            <?php endif; ?>
                                            <?php endif; ?>
                                            <?php if (!empty($item['tp_service_title' ])): ?>
                                            <div class="tp-slider-exp-item__content">
                                                <h4 class="tp-exp-sm-title">
                                                    <?php echo tp_kses($item['tp_service_title' ]); ?>
                                                </h4>
                                            </div>
                                            <?php endif; ?>

                                            <?php if(!empty($item['tp_services_btn_text'])) : ?>
                                            <div class="tp-slider-exp-item__service-link">
                                                <div class="tp-link tp-link-green">
                                                    <a href="<?php echo esc_url($link); ?>"
                                                        target="<?php echo esc_attr($target); ?>"
                                                        rel="<?php echo esc_attr($rel); ?>">
                                                        <svg width="34" height="16" viewBox="0 0 34 16" fill="none"
                                                            xmlns="http://www.w3.org/2000/svg">
                                                            <path
                                                                d="M33.7071 8.70711C34.0976 8.31659 34.0976 7.68342 33.7071 7.2929L27.3431 0.928935C26.9526 0.53841 26.3195 0.53841 25.9289 0.928934C25.5384 1.31946 25.5384 1.95262 25.9289 2.34315L31.5858 8L25.9289 13.6569C25.5384 14.0474 25.5384 14.6805 25.9289 15.0711C26.3195 15.4616 26.9526 15.4616 27.3431 15.0711L33.7071 8.70711ZM-8.74228e-08 9L33 9L33 7L8.74228e-08 7L-8.74228e-08 9Z"
                                                                fill="#202026" />
                                                        </svg>
                                                        <span><?php echo tp_kses($item['tp_services_btn_text']); ?></span>
                                                    </a>
                                                </div>
                                            </div>
                                            <?php endif; ?>

                                        </div>
                                    </div>
                                    <?php endforeach; ?>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <?php endif; ?>

                <?php 
		
	}

}

$widgets_manager->register( new TP_Hero_Banner() );