<?php
namespace TPCore\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Repeater;
use \Elementor\Utils;
use \Elementor\Control_Media;
use TPCore\Elementor\Controls\Group_Control_TPBGGradient;
use TPCore\Elementor\Controls\Group_Control_TPGradient;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Tp Core
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class About_Me extends Widget_Base {

    // use \TPCore\Widgets\TPCoreElementFunctions;

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'tp-about-me';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'About Me', 'tpcore' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'tp-icon';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'tpcore' ];
	}

	/**
	 * Retrieve the list of scripts the widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends() {
		return [ 'tpcore' ];
	}

	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
    protected function register_controls(){
        $this->register_controls_section();
        $this->style_tab_content();
    }  

	protected function register_controls_section() {

        // layout Panel
        $this->start_controls_section(
            'tp_layout',
            [
                'label' => esc_html__('Design Layout', 'tpcore'),
            ]
        );
        $this->add_control(
            'tp_design_style',
            [
                'label' => esc_html__('Select Layout', 'tpcore'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'layout-1' => esc_html__('Layout 1', 'tpcore'),
                    'layout-2' => esc_html__('Layout 2', 'tpcore'),
                ],
                'default' => 'layout-1',
            ]
        );

        $this->end_controls_section();


        // tp_section_title
        $this->start_controls_section(
            'tp_section_title',
            [
                'label' => esc_html__('Title & Content', 'tpcore'),
            ]
        );

        $this->add_control(
            'tp_title',
            [
                'label' => esc_html__('Title', 'tpcore'),
                'description' => tp_get_allowed_html_desc( 'intermediate' ),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('TP Title Here', 'tpcore'),
                'placeholder' => esc_html__('Type Heading Text', 'tpcore'),
                'label_block' => true,
            ]
        );    

        $this->add_control(
            'tp_sub_title',
            [
                'label' => esc_html__('Sub Title', 'tpcore'),
                'description' => tp_get_allowed_html_desc( 'basic' ),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('TP Sub Title', 'tpcore'),
                'placeholder' => esc_html__('Type Sub Heading Text', 'tpcore'),
                'label_block' => true,
                'condition' => ['tp_design_style' => 'layout-1']
            ]
        );

        $this->add_control(
            'tp_description',
            [
                'label' => esc_html__('Description', 'tpcore'),
                'description' => tp_get_allowed_html_desc( 'basic' ),
                'type' => Controls_Manager::TEXTAREA,
                'default' => esc_html__('Write Description Here', 'tpcore'),
                'placeholder' => esc_html__('Type Description Text', 'tpcore'),
                'label_block' => true,
            ]
        );

        $this->add_control(
            'tp_title_tag',
            [
                'label' => esc_html__('Title HTML Tag', 'tpcore'),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'h1' => [
                        'title' => esc_html__('H1', 'tpcore'),
                        'icon' => 'eicon-editor-h1'
                    ],
                    'h2' => [
                        'title' => esc_html__('H2', 'tpcore'),
                        'icon' => 'eicon-editor-h2'
                    ],
                    'h3' => [
                        'title' => esc_html__('H3', 'tpcore'),
                        'icon' => 'eicon-editor-h3'
                    ],
                    'h4' => [
                        'title' => esc_html__('H4', 'tpcore'),
                        'icon' => 'eicon-editor-h4'
                    ],
                    'h5' => [
                        'title' => esc_html__('H5', 'tpcore'),
                        'icon' => 'eicon-editor-h5'
                    ],
                    'h6' => [
                        'title' => esc_html__('H6', 'tpcore'),
                        'icon' => 'eicon-editor-h6'
                    ]
                ],
                'default' => 'h2',
                'toggle' => false,
            ]
        );

        $this->end_controls_section();


        // list group
        $this->start_controls_section(
            'tp_list',
            [
                'label' => esc_html__('Skills', 'tpcore'),
                'description' => esc_html__( 'Control all the style settings from Style tab', 'tpcore' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $repeater = new \Elementor\Repeater();

        $repeater->add_control(
            'tp_list_text', [
                'label' => esc_html__('Title', 'tpcore'),
                'description' => tp_get_allowed_html_desc( 'basic' ),
                'type' => \Elementor\Controls_Manager::TEXTAREA,
                'default' => esc_html__('Easy & Emergency Solutions Anytime', 'tpcore'),
                'label_block' => true,
            ]
        );

        $this->add_control(
            'tp_list_list',
            [
                'label' => esc_html__('Skills - List', 'tpcore'),
                'type' => \Elementor\Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'default' => [
                    [
                        'tp_list_text' => esc_html__('Performance Improve', 'tpcore'),
                    ],
                    [
                        'tp_list_text' => esc_html__('Performance Improve', 'tpcore')
                    ],
                    [
                        'tp_list_text' => esc_html__('Performance Improve', 'tpcore')
                    ],
                    [
                        'tp_list_text' => esc_html__('Performance Improve', 'tpcore')
                    ]
                ],
                'title_field' => '{{{ tp_list_text }}}',
            ]
        );
        $this->end_controls_section();


        // Social links
        $this->start_controls_section(
            'tp_social',
            [
                'label' => esc_html__('Social Links', 'tpcore'),
                'description' => esc_html__( 'Control all the style settings from Style tab', 'tpcore' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'tp_social_facebook',
            [
                'label' => esc_html__('Facebook', 'tpcore'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('#', 'tpcore'),
                'title' => esc_html__('Enter Social Links', 'tpcore'),
                'label_block' => true,
            ]
        );

        $this->add_control(
            'tp_social_pinterest',
            [
                'label' => esc_html__('Pinterest', 'tpcore'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('#', 'tpcore'),
                'title' => esc_html__('Enter Social Links', 'tpcore'),
                'label_block' => true,
            ]
        );

        $this->add_control(
            'tp_social_behance',
            [
                'label' => esc_html__('Behance', 'tpcore'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('#', 'tpcore'),
                'title' => esc_html__('Enter Social Links', 'tpcore'),
                'label_block' => true,
            ]
        );

        $this->add_control(
            'tp_social_twitter',
            [
                'label' => esc_html__('Twitter', 'tpcore'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('#', 'tpcore'),
                'title' => esc_html__('Enter Social Links', 'tpcore'),
                'label_block' => true,
            ]
        );

        $this->add_control(
            'tp_social_youtube',
            [
                'label' => esc_html__('Youtube', 'tpcore'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('#', 'tpcore'),
                'title' => esc_html__('Enter Social Links', 'tpcore'),
                'label_block' => true,
            ]
        );

        $this->add_control(
            'tp_social_linkedin',
            [
                'label' => esc_html__('Linkedin', 'tpcore'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('#', 'tpcore'),
                'title' => esc_html__('Enter Social Links', 'tpcore'),
                'label_block' => true,
            ]
        );

        $this->end_controls_section();

	}


    // style_tab_content
    protected function style_tab_content(){
        $this->start_controls_section(
            'tp_section_styling',
            [
                'label' => esc_html__('Section Style', 'tp-core'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'tp_area_background',
                'label' => esc_html__('Background', 'tp-core'),
                'types' => ['classic', 'gradient'],
                'selector' => '{{WRAPPER}} .tp-bg-img',
            ]
        );
        $this->add_group_control(
            Group_Control_TPBGGradient::get_type(),
            [
                'name' => 'tp_section_advs',
                'label' => esc_html__('Color', 'tp-core'),
                'selector' => '{{WRAPPER}} .tp-section-style',
            ]
        );
       $this->add_control(
           'tp_section_bg_color',
           [
               'label' => esc_html__('Background Color', 'tp-core'),
               'type' => Controls_Manager::COLOR,
               'selectors' => [
                   '{{WRAPPER}} .tp-section-style' => 'background: {{VALUE}};',
               ],
           ]
       );
        $this->add_responsive_control(
            'tp_section_padding',
            [
                'label' => esc_html__('Padding', 'tp-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .tp-section-style' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator' => 'before',
            ]
        );
        $this->add_responsive_control(
            'tp_section_margin',
            [
                'label' => esc_html__('Margin', 'tp-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .tp-section-style' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator' => 'before',
            ]
        );
        $this->end_controls_section();

        // _section_style_content
        $this->start_controls_section(
            '_section_style_content',
            [
                'label' => __( 'Title / Content', 'tp-core' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );


        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'content_background',
                'selector' => '{{WRAPPER}} .tp-el-content',
                'exclude' => [
                    'image'
                ]
            ]
        );

        // Title
        $this->add_control(
            '_heading_title',
            [
                'type' => Controls_Manager::HEADING,
                'label' => __( 'Title', 'tp-core' ),
                'separator' => 'before'
            ]
        );


        $this->add_group_control(
            Group_Control_TPGradient::get_type(),
            [
                'name' => 'tp_section_title',
                'label' => esc_html__('Color', 'tp-core'),
                'selector' => '{{WRAPPER}} .tp-el-title',
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'tp_title_typography',
                'selector' => '{{WRAPPER}} .tp-el-title',
            ]
        );

        $this->add_responsive_control(
            'tp_section_title_padding',
            [
                'label' => esc_html__('Padding', 'tp-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .tp-el-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator' => 'before',
            ]
        );
        $this->add_responsive_control(
            'tp_section_title_margin',
            [
                'label' => esc_html__('Margin', 'tp-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .tp-el-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator' => 'before',
            ]
        );




        $this->end_controls_section();


        // _section_sub_title_content
        $this->start_controls_section(
            '_section_sub_title_content',
            [
                'label' => __( 'Subtitle', 'tp-core' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );


        $this->add_responsive_control(
            'subtitle_spacing',
            [
                'label' => __( 'Bottom Spacing', 'tp-core' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'selectors' => [
                    '{{WRAPPER}} .tp-el-subtitle' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

       $this->add_group_control(
            Group_Control_TPGradient::get_type(),
            [
                'name' => 'tp_subtitle_color',
                'label' => esc_html__('Color', 'tp-core'),
                'selector' => '{{WRAPPER}} .tp-el-subtitle',
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'tp_subtitle_typography',
                'selector' => '{{WRAPPER}} .tp-el-subtitle',
            ]
        );

        $this->add_responsive_control(
            'tp_section_sub_title_padding',
            [
                'label' => esc_html__('Padding', 'tp-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .tp-el-subtitle' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator' => 'before',
            ]
        );
        $this->add_responsive_control(
            'tp_section_sub_title_margin',
            [
                'label' => esc_html__('Margin', 'tp-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .tp-el-subtitle' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator' => 'before',
            ]
        );


        $this->end_controls_section();


        // _section_style_content
        $this->start_controls_section(
            '_section_content_description',
            [
                'label' => __( 'Description', 'tp-core' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_responsive_control(
            'description_spacing',
            [
                'label' => __( 'Bottom Spacing', 'tp-core' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'selectors' => [
                    '{{WRAPPER}} .tp-el-content p' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'description_color',
            [
                'label' => __( 'Text Color', 'tp-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .tp-el-content p' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'tp_content_typography',
                'selector' => '{{WRAPPER}} .tp-el-content p',
            ]
        );

                $this->add_responsive_control(
            'tp_section_description_padding',
            [
                'label' => esc_html__('Padding', 'tp-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .tp-el-content p' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator' => 'before',
            ]
        );
        $this->add_responsive_control(
            'tp_section_description_margin',
            [
                'label' => esc_html__('Margin', 'tp-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .tp-el-content p' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator' => 'before',
            ]
        );


        $this->end_controls_section();


    }

	/**
	 * Render the widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

        if($settings['tp_design_style'] == 'layout-2') : 

        if ( !empty($settings['tp_image']['url']) ) {
            $tp_image = !empty($settings['tp_image']['id']) ? wp_get_attachment_image_url( $settings['tp_image']['id'], $settings['tp_image_size_size']) : $settings['tp_image']['url'];
            $tp_image_alt = get_post_meta($settings["tp_image"]["id"], "_wp_attachment_image_alt", true);
        }

        $this->add_render_attribute('title_args', 'class', 'case-details-title mb-50');
        
        ?>


<div class="am-about-area ">
    <div class="container">
        <div class="row case-custom-space-1">
            <div class="col-xl-8">
                <div class="sv-details-content case-custom-space-2">

                    <?php
                    if ( !empty($settings['tp_title' ]) ) :
                        printf( '<%1$s %2$s>%3$s</%1$s>',
                            tag_escape( $settings['tp_title_tag'] ),
                            $this->get_render_attribute_string( 'title_args' ),
                            tp_kses( $settings['tp_title' ] )
                            );
                    endif;
                    ?>

                    <?php if ( !empty($settings['tp_description']) ) : ?>
                    <p class="pb-30"><?php echo tp_kses( $settings['tp_description'] ); ?></p>
                    <?php endif; ?>
                    
                </div>
            </div>
            <div class="col-xl-4">
                <div class="row case-custom-space-3">
                    <div class="col-xl-12 col-lg-6 col-md-6">
                        <div class="amaboutinfo mb-30">
                            <div class="amaboutinfo__experience">
                                <?php foreach ($settings['tp_list_list'] as $key => $item) : ?>
                                <?php if(!empty($item['tp_list_text' ])) : ?>
                                <p><?php echo tp_kses($item['tp_list_text' ]);?></p>
                                <?php endif; ?>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-12 col-lg-6 col-md-6">
                        <div class="case-social-icon">

                            <?php if(!empty($settings['tp_social_behance'])) : ?>
                                <a class="behance w-100" href="<?php echo esc_url($settings['tp_social_behance']);?>"><i class="fab fa-behance"></i></a>
                            <?php endif; ?>

                            <?php if(!empty($settings['tp_social_twitter'])) : ?>
                                <a class="twitter w-100" href="<?php echo esc_url($settings['tp_social_twitter']);?>"><i class="fab fa-twitter"></i></a>
                            <?php endif; ?>

                            <?php if(!empty($settings['tp_social_pinterest'])) : ?>
                                <a class="pinterest w-100" href="<?php echo esc_url($settings['tp_social_pinterest']);?>"><i class="fab fa-pinterest"></i></a>
                            <?php endif; ?>

                            <?php if(!empty($settings['tp_social_facebook'])) : ?>
                                <a class="twitter w-100" href="<?php echo esc_url($settings['tp_social_facebook']);?>"><i class="fab fa-facebook-f"></i></a>
                            <?php endif; ?>

                            <?php if(!empty($settings['tp_social_youtube'])) : ?>
                                <a class="pinterest w-100" href="<?php echo esc_url($settings['tp_social_youtube']);?>"><i class="fab fa-youtube"></i></a>
                            <?php endif; ?>

                            <?php if(!empty($settings['tp_social_linkedin'])) : ?>
                                <a class="twitter w-100" href="<?php echo esc_url($settings['tp_social_linkedin']);?>"><i class="fab fa-linkedin"></i></a>
                            <?php endif; ?>

                            
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php else : 
        if ( !empty($settings['tp_image']['url']) ) {
            $tp_image = !empty($settings['tp_image']['id']) ? wp_get_attachment_image_url( $settings['tp_image']['id'], $settings['tp_image_size_size']) : $settings['tp_image']['url'];
            $tp_image_alt = get_post_meta($settings["tp_image"]["id"], "_wp_attachment_image_alt", true);
        }

        $this->add_render_attribute('title_args', 'class', 'name');
        ?>

<div class="am-about-area pt-10 pb-10">
    <div class="container">
        <div class="row ab-info-space">
            <div class="col-xl-4 col-lg-4 col-md-5 col-sm-12 mb-40 wow tpfadeUp" data-wow-duration=".7s"
                data-wow-delay=".7s">
                <div class="amaboutinfo">
                    <div class="amaboutinfo__client-info">

                        <?php
                        if ( !empty($settings['tp_title' ]) ) :
                            printf( '<%1$s %2$s>%3$s</%1$s>',
                                tag_escape( $settings['tp_title_tag'] ),
                                $this->get_render_attribute_string( 'title_args' ),
                                tp_kses( $settings['tp_title' ] )
                                );
                        endif;
                        ?>

                        <?php if ( !empty($settings['tp_sub_title']) ) : ?>
                        <span><?php echo tp_kses( $settings['tp_sub_title'] ); ?></span>
                        <?php endif; ?>

                        <?php if ( !empty($settings['tp_description']) ) : ?>
                        <p><?php echo tp_kses( $settings['tp_description'] ); ?></p>
                        <?php endif; ?>

                    </div>
                </div>
            </div>
            <div class="col-xl-6 col-lg-5 col-md-4 col-sm-12 mb-40 d-flex justify-content-start justify-content-md-center wow tpfadeUp"
                data-wow-duration=".7s" data-wow-delay=".9s">
                <div class="amaboutinfo">
                    <div class="amaboutinfo__experience">

                        <?php foreach ($settings['tp_list_list'] as $key => $item) : ?>
                        <?php if(!empty($item['tp_list_text' ])) : ?>
                        <p><?php echo tp_kses($item['tp_list_text' ]);?></p>
                        <?php endif; ?>
                        <?php endforeach; ?>

                    </div>
                </div>
            </div>
            <div class="col-xl-2 col-lg-2 col-md-3 col-sm-12 mb-40 wow tpfadeUp" data-wow-duration=".7s"
                data-wow-delay="1s">
                <div class="amaboutsocial text-start text-md-end">

                    <?php if(!empty($settings['tp_social_facebook'])) : ?>
                    <div class="amaboutsocial__icon mb-30">
                        <a href="<?php echo esc_url($settings['tp_social_facebook']);?>" class="si-btn-link">
                            <div class="tp-si-wrapper d-flex justify-content-end">
                                <div class="tp-si__text">
                                    <span><?php echo esc_html__('Facebook', 'tpcore'); ?></span>
                                </div>
                                <div class="tp-si__icon"><i class="fab fa-facebook-f"></i></div>
                            </div>
                        </a>
                    </div>
                    <?php endif; ?>

                    <?php if(!empty($settings['tp_social_pinterest'])) : ?>
                    <div class="amaboutsocial__icon mb-30">
                        <a href="<?php echo esc_url($settings['tp_social_pinterest']);?>" class="si-btn-link">
                            <div class="tp-si-wrapper d-flex justify-content-end">
                                <div class="tp-si__text tp-si-color-1">
                                    <span><?php echo esc_html__('Pintarest', 'tpcore'); ?></span>
                                </div>
                                <div class="tp-si__icon tp-si-color-1"><i class="fab fa-pinterest-p"></i></div>
                            </div>
                        </a>
                    </div>
                    <?php endif; ?>

                    <?php if(!empty($settings['tp_social_behance'])) : ?>
                    <div class="amaboutsocial__icon mb-30">
                        <a href="<?php echo esc_url($settings['tp_social_behance']);?>" class="si-btn-link">
                            <div class="tp-si-wrapper d-flex justify-content-end">
                                <div class="tp-si__text  tp-si-color-2">
                                    <span><?php echo esc_html__('Behance', 'tpcore'); ?></span>
                                </div>
                                <div class="tp-si__icon  tp-si-color-2"><i class="fab fa-behance"></i></div>
                            </div>
                        </a>
                    </div>
                    <?php endif; ?>

                    <?php if(!empty($settings['tp_social_twitter'])) : ?>
                    <div class="amaboutsocial__icon mb-30">
                        <a href="<?php echo esc_url($settings['tp_social_twitter']);?>" class="si-btn-link">
                            <div class="tp-si-wrapper d-flex justify-content-end">
                                <div class="tp-si__text  tp-si-color-5">
                                    <span><?php echo esc_html__('Twitter', 'tpcore'); ?></span>
                                </div>
                                <div class="tp-si__icon  tp-si-color-5"><i class="fab fa-twitter"></i>
                                </div>
                            </div>
                        </a>
                    </div>
                    <?php endif; ?>

                    <?php if(!empty($settings['tp_social_youtube'])) : ?>
                    <div class="amaboutsocial__icon mb-30">
                        <a href="<?php echo esc_url($settings['tp_social_youtube']);?>" class="si-btn-link">
                            <div class="tp-si-wrapper d-flex justify-content-end">
                                <div class="tp-si__text  tp-si-color-4">
                                    <span><?php echo esc_html__('Youtube', 'tpcore'); ?></span>
                                </div>
                                <div class="tp-si__icon  tp-si-color-4"><i class="fab fa-youtube"></i>
                                </div>
                            </div>
                        </a>
                    </div>
                    <?php endif; ?>

                    <?php if(!empty($settings['tp_social_linkedin'])) : ?>
                    <div class="amaboutsocial__icon mb-30">
                        <a href="<?php echo esc_url($settings['tp_social_linkedin']);?>" class="si-btn-link">
                            <div class="tp-si-wrapper d-flex justify-content-end">
                                <div class="tp-si__text">
                                    <span><?php echo esc_html__('Linkedin', 'tpcore'); ?></span>
                                </div>
                                <div class="tp-si__icon"><i class="fab fa-linkedin-in"></i></div>
                            </div>
                        </a>
                    </div>
                    <?php endif; ?>

                </div>
            </div>
        </div>
    </div>
</div>

<?php endif; 

	}
}

$widgets_manager->register( new About_Me() );