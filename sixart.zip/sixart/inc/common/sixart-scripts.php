<?php

/**
 * sixart_scripts description
 * @return [type] [description]
 */
function sixart_scripts() {

    /**
     * all css files 
    */

    wp_enqueue_style( 'sixart-fonts', sixart_fonts_url(), array(), '1.0.0' );
    if( is_rtl() ){
        wp_enqueue_style( 'bootstrap-rtl', SIXART_THEME_CSS_DIR.'bootstrap.rtl.min.css', array() );
    }else{
        wp_enqueue_style( 'bootstrap', SIXART_THEME_CSS_DIR.'bootstrap.min.css', array() );
    }
    wp_enqueue_style( 'animate', SIXART_THEME_CSS_DIR . 'animate.css', [] );
    wp_enqueue_style( 'sixart-custom-animation', SIXART_THEME_CSS_DIR . 'custom-animation.css', [] );
    wp_enqueue_style( 'slick', SIXART_THEME_CSS_DIR . 'slick.css', [] );
    wp_enqueue_style( 'nice-select', SIXART_THEME_CSS_DIR . 'nice-select.css', [] );
    wp_enqueue_style( 'flaticon', SIXART_THEME_CSS_DIR . 'flaticon.css', [] );
    wp_enqueue_style( 'meanmenu', SIXART_THEME_CSS_DIR . 'meanmenu.css', [] );
    wp_enqueue_style( 'font-awesome-pro', SIXART_THEME_CSS_DIR . 'font-awesome-pro.css', [] );
    wp_enqueue_style( 'magnific-popup', SIXART_THEME_CSS_DIR . 'magnific-popup.css', [] );
    wp_enqueue_style( 'jquery-fancybox', SIXART_THEME_CSS_DIR . 'spacing.css', [] );
    wp_enqueue_style( 'sixart-woo', SIXART_THEME_CSS_DIR . 'woo.css', [] );
    wp_enqueue_style( 'sixart-core', SIXART_THEME_CSS_DIR . 'sixart-core.css', [] );
    wp_enqueue_style( 'sixart-unit', SIXART_THEME_CSS_DIR . 'sixart-unit.css', [] );
    wp_enqueue_style( 'sixart-custom', SIXART_THEME_CSS_DIR . 'sixart-custom.css', [] );
    wp_enqueue_style( 'sixart-style', get_stylesheet_uri() );

    // all js
    wp_enqueue_script( 'waypoints', SIXART_THEME_JS_DIR . 'waypoints.js', [ 'jquery' ], false, true );
    wp_enqueue_script( 'bootstrap-bundle', SIXART_THEME_JS_DIR . 'bootstrap.bundle.min.js', [ 'jquery' ], '', true );
    wp_enqueue_script( 'slick', SIXART_THEME_JS_DIR . 'slick.js', [ 'jquery' ], false, true );
    wp_enqueue_script( 'magnific-popup', SIXART_THEME_JS_DIR . 'magnific-popup.js', [ 'jquery' ], '', true );
    wp_enqueue_script( 'counterup', SIXART_THEME_JS_DIR . 'counterup.js', [ 'jquery' ], false, true );
    wp_enqueue_script( 'wow', SIXART_THEME_JS_DIR . 'wow.js', [ 'jquery' ], false, true );
    wp_enqueue_script( 'nice-select', SIXART_THEME_JS_DIR . 'nice-select.js', [ 'jquery' ], '', true );
    wp_enqueue_script( 'meanmenu', SIXART_THEME_JS_DIR . 'meanmenu.js', [ 'jquery' ], false, true );
    wp_enqueue_script( 'isotope-pkgd', SIXART_THEME_JS_DIR . 'isotope-pkgd.js', [ 'imagesloaded' ], false, true );
    wp_enqueue_script( 'sixart-main', SIXART_THEME_JS_DIR . 'main.js', [ 'jquery' ], false, true );

    if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
        wp_enqueue_script( 'comment-reply' );
    }
}
add_action( 'wp_enqueue_scripts', 'sixart_scripts' );

/*
Register Fonts
 */
function sixart_fonts_url() {
    $font_url = '';

    /*
    Translators: If there are characters in your language that are not supported
    by chosen font(s), translate this to 'off'. Do not translate into your own language.
     */
    if ( 'off' !== _x( 'on', 'Google font: on or off', 'sixart' ) ) {
        $font_url = 'https://fonts.googleapis.com/css2?'. urlencode('family=Arimo:wght@400;500;600;700&family=Poppins:wght@300;400;500;600;700;800&display=swap');
        
    }
    return $font_url;
}