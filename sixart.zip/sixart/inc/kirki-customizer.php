<?php
/**
 * sixart customizer
 *
 * @package sixart
 */

// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Added Panels & Sections
 */
function sixart_customizer_panels_sections( $wp_customize ) {

    //Add panel
    $wp_customize->add_panel( 'sixart_customizer', [
        'priority' => 10,
        'title'    => esc_html__( 'Sixart Customizer', 'sixart' ),
    ] );

    /**
     * Customizer Section
     */
    $wp_customize->add_section( 'header_top_setting', [
        'title'       => esc_html__( 'Header Info Setting', 'sixart' ),
        'description' => '',
        'priority'    => 10,
        'capability'  => 'edit_theme_options',
        'panel'       => 'sixart_customizer',
    ] );

    $wp_customize->add_section( 'header_social', [
        'title'       => esc_html__( 'Header Social', 'sixart' ),
        'description' => '',
        'priority'    => 11,
        'capability'  => 'edit_theme_options',
        'panel'       => 'sixart_customizer',
    ] );

    $wp_customize->add_section( 'section_header_logo', [
        'title'       => esc_html__( 'Header Setting', 'sixart' ),
        'description' => '',
        'priority'    => 12,
        'capability'  => 'edit_theme_options',
        'panel'       => 'sixart_customizer',
    ] );

    $wp_customize->add_section( 'blog_setting', [
        'title'       => esc_html__( 'Blog Setting', 'sixart' ),
        'description' => '',
        'priority'    => 13,
        'capability'  => 'edit_theme_options',
        'panel'       => 'sixart_customizer',
    ] );

    $wp_customize->add_section( 'header_side_setting', [
        'title'       => esc_html__( 'Side Info', 'sixart' ),
        'description' => '',
        'priority'    => 14,
        'capability'  => 'edit_theme_options',
        'panel'       => 'sixart_customizer',
    ] );

    $wp_customize->add_section( 'breadcrumb_setting', [
        'title'       => esc_html__( 'Breadcrumb Setting', 'sixart' ),
        'description' => '',
        'priority'    => 15,
        'capability'  => 'edit_theme_options',
        'panel'       => 'sixart_customizer',
    ] );

    $wp_customize->add_section( 'blog_setting', [
        'title'       => esc_html__( 'Blog Setting', 'sixart' ),
        'description' => '',
        'priority'    => 16,
        'capability'  => 'edit_theme_options',
        'panel'       => 'sixart_customizer',
    ] );

    $wp_customize->add_section( 'footer_setting', [
        'title'       => esc_html__( 'Footer Settings', 'sixart' ),
        'description' => '',
        'priority'    => 16,
        'capability'  => 'edit_theme_options',
        'panel'       => 'sixart_customizer',
    ] );

    $wp_customize->add_section( 'footer_social', [
        'title'       => esc_html__( 'Footer Social', 'sixart' ),
        'description' => '',
        'priority'    => 16,
        'capability'  => 'edit_theme_options',
        'panel'       => 'sixart_customizer',
    ] );

    $wp_customize->add_section( 'color_setting', [
        'title'       => esc_html__( 'Color Setting', 'sixart' ),
        'description' => '',
        'priority'    => 17,
        'capability'  => 'edit_theme_options',
        'panel'       => 'sixart_customizer',
    ] );

    $wp_customize->add_section( '404_page', [
        'title'       => esc_html__( '404 Page', 'sixart' ),
        'description' => '',
        'priority'    => 18,
        'capability'  => 'edit_theme_options',
        'panel'       => 'sixart_customizer',
    ] );

    $wp_customize->add_section( 'typo_setting', [
        'title'       => esc_html__( 'Typography Setting', 'sixart' ),
        'description' => '',
        'priority'    => 21,
        'capability'  => 'edit_theme_options',
        'panel'       => 'sixart_customizer',
    ] );

    $wp_customize->add_section( 'slug_setting', [
        'title'       => esc_html__( 'Slug Settings', 'sixart' ),
        'description' => '',
        'priority'    => 22,
        'capability'  => 'edit_theme_options',
        'panel'       => 'sixart_customizer',
    ] );

    $wp_customize->add_section( 'woo_setting', [
        'title'       => esc_html__( 'Woocommerce Settings', 'sixart' ),
        'description' => '',
        'priority'    => 22,
        'capability'  => 'edit_theme_options',
        'panel'       => 'sixart_customizer',
    ] );
}

add_action( 'customize_register', 'sixart_customizer_panels_sections' );

function _header_top_fields( $fields ) {
   
    $fields[] = [
        'type'     => 'switch',
        'settings' => 'sixart_preloader',
        'label'    => esc_html__( 'Preloader On/Off', 'sixart' ),
        'section'  => 'header_top_setting',
        'default'  => '0',
        'priority' => 10,
        'choices'  => [
            'on'  => esc_html__( 'Enable', 'sixart' ),
            'off' => esc_html__( 'Disable', 'sixart' ),
        ],
    ];


    $fields[] = [
        'type'     => 'switch',
        'settings' => 'sixart_backtotop',
        'label'    => esc_html__( 'Back To Top On/Off', 'sixart' ),
        'section'  => 'header_top_setting',
        'default'  => '0',
        'priority' => 10,
        'choices'  => [
            'on'  => esc_html__( 'Enable', 'sixart' ),
            'off' => esc_html__( 'Disable', 'sixart' ),
        ],
    ];

    $fields[] = [
        'type'     => 'switch',
        'settings' => 'sixart_header_right',
        'label'    => esc_html__( 'Header Right On/Off', 'sixart' ),
        'section'  => 'header_top_setting',
        'default'  => '0',
        'priority' => 10,
        'choices'  => [
            'on'  => esc_html__( 'Enable', 'sixart' ),
            'off' => esc_html__( 'Disable', 'sixart' ),
        ],
    ];

    $fields[] = [
        'type'     => 'switch',
        'settings' => 'sixart_search',
        'label'    => esc_html__( 'Header Search On/Off', 'sixart' ),
        'section'  => 'header_top_setting',
        'default'  => '0',
        'priority' => 10,
        'choices'  => [
            'on'  => esc_html__( 'Enable', 'sixart' ),
            'off' => esc_html__( 'Disable', 'sixart' ),
        ],
    ];

    $fields[] = [
        'type'     => 'switch',
        'settings' => 'sixart_mini_cart',
        'label'    => esc_html__( 'Mini Cart On/Off', 'sixart' ),
        'section'  => 'header_top_setting',
        'default'  => '0',
        'priority' => 10,
        'choices'  => [
            'on'  => esc_html__( 'Enable', 'sixart' ),
            'off' => esc_html__( 'Disable', 'sixart' ),
        ],
    ];

    // button
    $fields[] = [
        'type'     => 'text',
        'settings' => 'sixart_button_text',
        'label'    => esc_html__( 'Button Text', 'sixart' ),
        'section'  => 'header_top_setting',
        'default'  => esc_html__( 'Get A Quote', 'sixart' ),
        'priority' => 10,
    ];

    $fields[] = [
        'type'     => 'link',
        'settings' => 'sixart_button_link',
        'label'    => esc_html__( 'Button URL', 'sixart' ),
        'section'  => 'header_top_setting',
        'default'  => esc_html__( '#', 'sixart' ),
        'priority' => 10,
    ];


    return $fields;

}
add_filter( 'kirki/fields', '_header_top_fields' );

/*
Header Social
 */
function _header_social_fields( $fields ) {
    // header section social
    $fields[] = [
        'type'     => 'text',
        'settings' => 'sixart_topbar_fb_url',
        'label'    => esc_html__( 'Facebook Url', 'sixart' ),
        'section'  => 'header_social',
        'default'  => esc_html__( '#', 'sixart' ),
        'priority' => 10,
    ];

    $fields[] = [
        'type'     => 'text',
        'settings' => 'sixart_topbar_twitter_url',
        'label'    => esc_html__( 'Twitter Url', 'sixart' ),
        'section'  => 'header_social',
        'default'  => esc_html__( '#', 'sixart' ),
        'priority' => 10,
    ];

    $fields[] = [
        'type'     => 'text',
        'settings' => 'sixart_topbar_instagram_url',
        'label'    => esc_html__( 'Instagram Url', 'sixart' ),
        'section'  => 'header_social',
        'default'  => esc_html__( '#', 'sixart' ),
        'priority' => 10,
    ];

    $fields[] = [
        'type'     => 'text',
        'settings' => 'sixart_topbar_youtube_url',
        'label'    => esc_html__( 'Youtube Url', 'sixart' ),
        'section'  => 'header_social',
        'default'  => esc_html__( '#', 'sixart' ),
        'priority' => 10,
    ];

    $fields[] = [
        'type'     => 'text',
        'settings' => 'sixart_topbar_dribbble',
        'label'    => esc_html__( 'Dribbble Url', 'sixart' ),
        'section'  => 'header_social',
        'default'  => esc_html__( '#', 'sixart' ),
        'priority' => 10,
    ];

    $fields[] = [
        'type'     => 'text',
        'settings' => 'sixart_topbar_behance',
        'label'    => esc_html__( 'Behance Url', 'sixart' ),
        'section'  => 'header_social',
        'default'  => esc_html__( '#', 'sixart' ),
        'priority' => 10,
    ];


    return $fields;
}
add_filter( 'kirki/fields', '_header_social_fields' );

/*
Header Settings
 */
function _header_header_fields( $fields ) {
    $fields[] = [
        'type'        => 'radio-image',
        'settings'    => 'choose_default_header',
        'label'       => esc_html__( 'Select Header Style', 'sixart' ),
        'section'     => 'section_header_logo',
        'placeholder' => esc_html__( 'Select an option...', 'sixart' ),
        'priority'    => 10,
        'multiple'    => 1,
        'choices'     => [
            'header-style-1'   => get_template_directory_uri() . '/inc/img/header/header-1.png',
            'header-style-2' => get_template_directory_uri() . '/inc/img/header/header-2.png',
            'header-style-3'  => get_template_directory_uri() . '/inc/img/header/header-3.png'
        ],
        'default'     => 'header-style-1',
    ];

    $fields[] = [
        'type'        => 'image',
        'settings'    => 'logo',
        'label'       => esc_html__( 'Header Logo', 'sixart' ),
        'description' => esc_html__( 'Upload Your Logo.', 'sixart' ),
        'section'     => 'section_header_logo',
        'default'     => get_template_directory_uri() . '/assets/img/logo/logo.png',
    ];

    $fields[] = [
        'type'        => 'image',
        'settings'    => 'seconday_logo',
        'label'       => esc_html__( 'Header Secondary Logo', 'sixart' ),
        'description' => esc_html__( 'Header Logo Black', 'sixart' ),
        'section'     => 'section_header_logo',
        'default'     => get_template_directory_uri() . '/assets/img/logo/logo-white.png',
    ];

    $fields[] = [
        'type'        => 'image',
        'settings'    => 'preloader_logo',
        'label'       => esc_html__( 'Preloader Logo', 'sixart' ),
        'description' => esc_html__( 'Upload Preloader Logo.', 'sixart' ),
        'section'     => 'section_header_logo',
        'default'     => get_template_directory_uri() . '/assets/img/favicon.png',
    ];

    return $fields;
}
add_filter( 'kirki/fields', '_header_header_fields' );

/*
Header Side Info
 */
function _header_side_fields( $fields ) {
    // side info settings
    $fields[] = [
        'type'     => 'switch',
        'settings' => 'sixart_side_hide',
        'label'    => esc_html__( 'Side Info On/Off', 'sixart' ),
        'section'  => 'header_side_setting',
        'default'  => '0',
        'priority' => 10,
        'choices'  => [
            'on'  => esc_html__( 'Enable', 'sixart' ),
            'off' => esc_html__( 'Disable', 'sixart' ),
        ],
    ];
    $fields[] = [
        'type'        => 'image',
        'settings'    => 'sixart_side_logo',
        'label'       => esc_html__( 'Logo Side', 'sixart' ),
        'description' => esc_html__( 'Logo Side', 'sixart' ),
        'section'     => 'header_side_setting',
        'default'     => get_template_directory_uri() . '/assets/img/logo/logo-white.png',
    ];
    $fields[] = [
        'type'     => 'textarea',
        'settings' => 'sixart_extra_about_text',
        'label'    => esc_html__( 'Side Description Text', 'sixart' ),
        'section'  => 'header_side_setting',
        'default'  => esc_html__( 'But I must explain to you how all this mistaken idea of denouncing pleasure and praising pain was born and will give you a complete account of the system and expound the actual teachings of the great explore', 'sixart' ),
        'priority' => 10,
    ];
    

    // contact
    $fields[] = [
        'type'     => 'text',
        'settings' => 'sixart_contact_title',
        'label'    => esc_html__( 'Contact Title', 'sixart' ),
        'section'  => 'header_side_setting',
        'default'  => esc_html__( 'Contact Title', 'sixart' ),
        'priority' => 10,
    ];

    $fields[] = [
        'type'     => 'text',
        'settings' => 'sixart_extra_email',
        'label'    => esc_html__( 'Email ID', 'sixart' ),
        'section'  => 'header_side_setting',
        'default'  => esc_html__( 'info@themepure.net', 'sixart' ),
        'priority' => 10,
    ];
    
    $fields[] = [
        'type'     => 'text',
        'settings' => 'sixart_extra_phone',
        'label'    => esc_html__( 'Phone Number', 'sixart' ),
        'section'  => 'header_side_setting',
        'default'  => esc_html__( '+0989 7876 9865 9', 'sixart' ),
        'priority' => 10,
    ];

    $fields[] = [
        'type'     => 'text',
        'settings' => 'sixart_extra_address',
        'label'    => esc_html__( 'Office Address', 'sixart' ),
        'section'  => 'header_side_setting',
        'default'  => esc_html__( '12/A, Mirnada City Tower, NYC', 'sixart' ),
        'priority' => 10,
    ];
    return $fields;
}
add_filter( 'kirki/fields', '_header_side_fields' );

/*
_header_page_title_fields
 */
function _header_page_title_fields( $fields ) {
    // Breadcrumb Setting
    $fields[] = [
        'type'        => 'image',
        'settings'    => 'breadcrumb_bg_img',
        'label'       => esc_html__( 'Breadcrumb Background Image', 'sixart' ),
        'description' => esc_html__( 'Breadcrumb Background Image', 'sixart' ),
        'section'     => 'breadcrumb_setting',
    ];
    $fields[] = [
        'type'        => 'color',
        'settings'    => 'sixart_breadcrumb_bg_color',
        'label'       => __( 'Breadcrumb BG Color', 'sixart' ),
        'description' => esc_html__( 'This is a Breadcrumb bg color control.', 'sixart' ),
        'section'     => 'breadcrumb_setting',
        'default'     => '#F7F7F7',
        'priority'    => 10,
    ];

    $fields[] = [
        'type'     => 'switch',
        'settings' => 'breadcrumb_info_switch',
        'label'    => esc_html__( 'Breadcrumb Info switch', 'sixart' ),
        'section'  => 'breadcrumb_setting',
        'default'  => '1',
        'priority' => 10,
        'choices'  => [
            'on'  => esc_html__( 'Enable', 'sixart' ),
            'off' => esc_html__( 'Disable', 'sixart' ),
        ],
    ];

    return $fields;
}
add_filter( 'kirki/fields', '_header_page_title_fields' );

/*
Header Social
 */
function _header_blog_fields( $fields ) {
// Blog Setting
    $fields[] = [
        'type'     => 'switch',
        'settings' => 'sixart_blog_btn_switch',
        'label'    => esc_html__( 'Blog BTN On/Off', 'sixart' ),
        'section'  => 'blog_setting',
        'default'  => '1',
        'priority' => 10,
        'choices'  => [
            'on'  => esc_html__( 'Enable', 'sixart' ),
            'off' => esc_html__( 'Disable', 'sixart' ),
        ],
    ];

    $fields[] = [
        'type'     => 'switch',
        'settings' => 'sixart_blog_cat',
        'label'    => esc_html__( 'Blog Category Meta On/Off', 'sixart' ),
        'section'  => 'blog_setting',
        'default'  => '0',
        'priority' => 10,
        'choices'  => [
            'on'  => esc_html__( 'Enable', 'sixart' ),
            'off' => esc_html__( 'Disable', 'sixart' ),
        ],
    ];

    $fields[] = [
        'type'     => 'switch',
        'settings' => 'sixart_blog_author',
        'label'    => esc_html__( 'Blog Author Meta On/Off', 'sixart' ),
        'section'  => 'blog_setting',
        'default'  => '1',
        'priority' => 10,
        'choices'  => [
            'on'  => esc_html__( 'Enable', 'sixart' ),
            'off' => esc_html__( 'Disable', 'sixart' ),
        ],
    ];
    $fields[] = [
        'type'     => 'switch',
        'settings' => 'sixart_blog_date',
        'label'    => esc_html__( 'Blog Date Meta On/Off', 'sixart' ),
        'section'  => 'blog_setting',
        'default'  => '1',
        'priority' => 10,
        'choices'  => [
            'on'  => esc_html__( 'Enable', 'sixart' ),
            'off' => esc_html__( 'Disable', 'sixart' ),
        ],
    ];
    $fields[] = [
        'type'     => 'switch',
        'settings' => 'sixart_blog_comments',
        'label'    => esc_html__( 'Blog Comments Meta On/Off', 'sixart' ),
        'section'  => 'blog_setting',
        'default'  => '1',
        'priority' => 10,
        'choices'  => [
            'on'  => esc_html__( 'Enable', 'sixart' ),
            'off' => esc_html__( 'Disable', 'sixart' ),
        ],
    ];

    
    $fields[] = [
        'type'     => 'switch',
        'settings' => 'sixart_singleblog_social',
        'label'    => esc_html__( 'Single Blog Social On/Off', 'sixart' ),
        'section'  => 'blog_setting',
        'default'  => '0',
        'priority' => 10,
        'choices'  => [
            'on'  => esc_html__( 'Enable', 'sixart' ),
            'off' => esc_html__( 'Disable', 'sixart' ),
        ],
    ];

    $fields[] = [
        'type'     => 'text',
        'settings' => 'sixart_blog_btn',
        'label'    => esc_html__( 'Blog Button text', 'sixart' ),
        'section'  => 'blog_setting',
        'default'  => esc_html__( 'Read More', 'sixart' ),
        'priority' => 10,
    ];

    $fields[] = [
        'type'     => 'text',
        'settings' => 'breadcrumb_blog_title',
        'label'    => esc_html__( 'Blog Title', 'sixart' ),
        'section'  => 'blog_setting',
        'default'  => esc_html__( 'Blog', 'sixart' ),
        'priority' => 10,
    ];

    $fields[] = [
        'type'     => 'text',
        'settings' => 'breadcrumb_blog_title_details',
        'label'    => esc_html__( 'Blog Details Title', 'sixart' ),
        'section'  => 'blog_setting',
        'default'  => esc_html__( 'Blog Details', 'sixart' ),
        'priority' => 10,
    ];
    return $fields;
}
add_filter( 'kirki/fields', '_header_blog_fields' );

/*
Footer
 */
function _header_footer_fields( $fields ) {
    // Footer Setting
    $fields[] = [
        'type'        => 'radio-image',
        'settings'    => 'choose_default_footer',
        'label'       => esc_html__( 'Choose Footer Style', 'sixart' ),
        'section'     => 'footer_setting',
        'default'     => '5',
        'placeholder' => esc_html__( 'Select an option...', 'sixart' ),
        'priority'    => 10,
        'multiple'    => 1,
        'choices'     => [
            'footer-style-1'   => get_template_directory_uri() . '/inc/img/footer/footer-1.png',
            'footer-style-2' => get_template_directory_uri() . '/inc/img/footer/footer-2.png',
            'footer-style-3' => get_template_directory_uri() . '/inc/img/footer/footer-3.png',
        ],
        'default'     => 'footer-style-1',
    ];

    $fields[] = [
        'type'        => 'select',
        'settings'    => 'footer_widget_number',
        'label'       => esc_html__( 'Widget Number', 'sixart' ),
        'section'     => 'footer_setting',
        'default'     => '4',
        'placeholder' => esc_html__( 'Select an option...', 'sixart' ),
        'priority'    => 10,
        'multiple'    => 1,
        'choices'     => [
            '4' => esc_html__( 'Widget Number 4', 'sixart' ),
            '3' => esc_html__( 'Widget Number 3', 'sixart' ),
            '2' => esc_html__( 'Widget Number 2', 'sixart' ),
        ],
    ];

    $fields[] = [
        'type'        => 'image',
        'settings'    => 'sixart_footer_bg',
        'label'       => esc_html__( 'Footer Background Image.', 'sixart' ),
        'description' => esc_html__( 'Footer Background Image.', 'sixart' ),
        'section'     => 'footer_setting',
    ];

    $fields[] = [
        'type'        => 'color',
        'settings'    => 'sixart_footer_bg_color',
        'label'       => __( 'Footer BG Color', 'sixart' ),
        'description' => esc_html__( 'This is a Footer bg color control.', 'sixart' ),
        'section'     => 'footer_setting',
        'default'     => '#151718',
        'priority'    => 10,
    ];

    $fields[] = [
        'type'     => 'switch',
        'settings' => 'footer_style_2_switch',
        'label'    => esc_html__( 'Footer Style 2 On/Off', 'sixart' ),
        'section'  => 'footer_setting',
        'default'  => '1',
        'priority' => 10,
        'choices'  => [
            'on'  => esc_html__( 'Enable', 'sixart' ),
            'off' => esc_html__( 'Disable', 'sixart' ),
        ],
    ];

    $fields[] = [
        'type'     => 'switch',
        'settings' => 'footer_style_3_switch',
        'label'    => esc_html__( 'Footer Style 3 On/Off', 'sixart' ),
        'section'  => 'footer_setting',
        'default'  => '1',
        'priority' => 10,
        'choices'  => [
            'on'  => esc_html__( 'Enable', 'sixart' ),
            'off' => esc_html__( 'Disable', 'sixart' ),
        ],
    ];

    $fields[] = [
        'type'     => 'switch',
        'settings' => 'footer_c_form_switch',
        'label'    => esc_html__( 'Footer Contact From On/Off', 'sixart' ),
        'section'  => 'footer_setting',
        'default'  => '0',
        'priority' => 10,
        'choices'  => [
            'on'  => esc_html__( 'Enable', 'sixart' ),
            'off' => esc_html__( 'Disable', 'sixart' ),
        ],
    ];

    $fields[] = [
        'type'     => 'text',
        'settings' => 'footer_c_title',
        'label'    => esc_html__( 'Form Title', 'sixart' ),
        'section'  => 'footer_setting',
        'default'  => esc_html__( 'Get latest updates', 'sixart' ),
        'priority' => 10,
        'active_callback' => [
            [
                'setting'  => 'footer_c_form_switch',
                'operator' => '==',
                'value'    => true,
            ]
        ],
    ];

    $fields[] = [
        'type'     => 'text',
        'settings' => 'footer_c_shortcode',
        'label'    => esc_html__( 'Form Shortcode', 'sixart' ),
        'section'  => 'footer_setting',
        'default'  => esc_html__( '[shortcode here]', 'sixart' ),
        'priority' => 10,
        'active_callback' => [
            [
                'setting'  => 'footer_c_form_switch',
                'operator' => '==',
                'value'    => true,
            ]
        ],
    ];

    $fields[] = [
        'type'     => 'text',
        'settings' => 'sixart_copyright',
        'label'    => esc_html__( 'Copy Right', 'sixart' ),
        'section'  => 'footer_setting',
        'default'  => esc_html__( 'Copyright &copy; 2022 Themeim. All Rights Reserved', 'sixart' ),
        'priority' => 10,
    ];

    $fields[] = [
        'type'     => 'textarea',
        'settings' => 'sixart_copyright_link',
        'label'    => esc_html__( 'Copy Right', 'sixart' ),
        'section'  => 'footer_setting',
        'priority' => 10,
    ];
    return $fields;
}
add_filter( 'kirki/fields', '_header_footer_fields' );


/*
Footer Social
 */
function _footer_social_fields( $fields ) {
    // footer section social
    $fields[] = [
        'type'     => 'switch',
        'settings' => 'footer_social_switch',
        'label'    => esc_html__( 'Footer Social On/Off', 'sixart' ),
        'section'  => 'footer_social',
        'default'  => '0',
        'priority' => 10,
        'choices'  => [
            'on'  => esc_html__( 'Enable', 'sixart' ),
            'off' => esc_html__( 'Disable', 'sixart' ),
        ],
    ];

    $fields[] = [
        'type'     => 'text',
        'settings' => 'sixart_footer_fb_url',
        'label'    => esc_html__( 'Facebook Url', 'sixart' ),
        'section'  => 'footer_social',
        'default'  => esc_html__( '#', 'sixart' ),
        'priority' => 10,
    ];

    $fields[] = [
        'type'     => 'text',
        'settings' => 'sixart_footer_youtube_url',
        'label'    => esc_html__( 'Youtube Url', 'sixart' ),
        'section'  => 'footer_social',
        'default'  => esc_html__( '#', 'sixart' ),
        'priority' => 10,
    ];

    $fields[] = [
        'type'     => 'text',
        'settings' => 'sixart_footer_behance_url',
        'label'    => esc_html__( 'Behance Url', 'sixart' ),
        'section'  => 'footer_social',
        'default'  => esc_html__( '#', 'sixart' ),
        'priority' => 10,
    ];

    $fields[] = [
        'type'     => 'text',
        'settings' => 'sixart_footer_dribbble_url',
        'label'    => esc_html__( 'Dribbble Url', 'sixart' ),
        'section'  => 'footer_social',
        'default'  => esc_html__( '#', 'sixart' ),
        'priority' => 10,
    ];

    $fields[] = [
        'type'     => 'text',
        'settings' => 'sixart_footer_twitter_url',
        'label'    => esc_html__( 'Twitter Url', 'sixart' ),
        'section'  => 'footer_social',
        'default'  => esc_html__( '#', 'sixart' ),
        'priority' => 10,
    ];

    $fields[] = [
        'type'     => 'text',
        'settings' => 'sixart_footer_linkedin_url',
        'label'    => esc_html__( 'Linkedin Url', 'sixart' ),
        'section'  => 'footer_social',
        'default'  => esc_html__( '#', 'sixart' ),
        'priority' => 10,
    ];

    $fields[] = [
        'type'     => 'text',
        'settings' => 'sixart_footer_instagram_url',
        'label'    => esc_html__( 'Instagram Url', 'sixart' ),
        'section'  => 'footer_social',
        'default'  => esc_html__( '#', 'sixart' ),
        'priority' => 10,
    ];


    return $fields;
}
add_filter( 'kirki/fields', '_footer_social_fields' );


// color
function sixart_color_fields( $fields ) {
    // Color Settings
    $fields[] = [
        'type'        => 'color',
        'settings'    => 'sixart_color_option',
        'label'       => __( 'Theme Color', 'sixart' ),
        'description' => esc_html__( 'This is a Theme color control.', 'sixart' ),
        'section'     => 'color_setting',
        'default'     => '#2b4eff',
        'priority'    => 10,
    ];
    // Color Settings
    $fields[] = [
        'type'        => 'color',
        'settings'    => 'sixart_color_option_2',
        'label'       => __( 'Primary Color', 'sixart' ),
        'description' => esc_html__( 'This is a Primary color control.', 'sixart' ),
        'section'     => 'color_setting',
        'default'     => '#f2277e',
        'priority'    => 10,
    ];
     // Color Settings
    $fields[] = [
        'type'        => 'color',
        'settings'    => 'sixart_color_option_3',
        'label'       => __( 'Secondary Color', 'sixart' ),
        'description' => esc_html__( 'This is a Secondary color control.', 'sixart' ),
        'section'     => 'color_setting',
        'default'     => '#30a820',
        'priority'    => 10,
    ];
     // Color Settings
    $fields[] = [
        'type'        => 'color',
        'settings'    => 'sixart_color_option_3_2',
        'label'       => __( 'Secondary Color 2', 'sixart' ),
        'description' => esc_html__( 'This is a Secondary color 2 control.', 'sixart' ),
        'section'     => 'color_setting',
        'default'     => '#ffb352',
        'priority'    => 10,
    ];
     // Color Settings
    $fields[] = [
        'type'        => 'color',
        'settings'    => 'sixart_color_scrollup',
        'label'       => __( 'ScrollUp Color', 'sixart' ),
        'description' => esc_html__( 'This is a ScrollUp colo control.', 'sixart' ),
        'section'     => 'color_setting',
        'default'     => '#2b4eff',
        'priority'    => 10,
    ];

    return $fields;
}
add_filter( 'kirki/fields', 'sixart_color_fields' );

// 404
function sixart_404_fields( $fields ) {
    // 404 settings
    $fields[] = [
        'type'     => 'text',
        'settings' => 'sixart_error_title',
        'label'    => esc_html__( 'Not Found Title', 'sixart' ),
        'section'  => '404_page',
        'default'  => esc_html__( 'Page not found', 'sixart' ),
        'priority' => 10,
    ];
    $fields[] = [
        'type'     => 'textarea',
        'settings' => 'sixart_error_desc',
        'label'    => esc_html__( '404 Description Text', 'sixart' ),
        'section'  => '404_page',
        'default'  => esc_html__( 'Oops! The page you are looking for does not exist. It might have been moved or deleted', 'sixart' ),
        'priority' => 10,
    ];
    $fields[] = [
        'type'     => 'text',
        'settings' => 'sixart_error_link_text',
        'label'    => esc_html__( '404 Link Text', 'sixart' ),
        'section'  => '404_page',
        'default'  => esc_html__( 'Back To Home', 'sixart' ),
        'priority' => 10,
    ];
    return $fields;
}
add_filter( 'kirki/fields', 'sixart_404_fields' );

/**
 * Added Fields
 */
function sixart_typo_fields( $fields ) {
    // typography settings
    $fields[] = [
        'type'        => 'typography',
        'settings'    => 'typography_body_setting',
        'label'       => esc_html__( 'Body Font', 'sixart' ),
        'section'     => 'typo_setting',
        'default'     => [
            'font-family'    => '',
            'variant'        => '',
            'font-size'      => '',
            'line-height'    => '',
            'letter-spacing' => '0',
            'color'          => '',
        ],
        'priority'    => 10,
        'transport'   => 'auto',
        'output'      => [
            [
                'element' => 'body',
            ],
        ],
    ];

    $fields[] = [
        'type'        => 'typography',
        'settings'    => 'typography_h_setting',
        'label'       => esc_html__( 'Heading h1 Fonts', 'sixart' ),
        'section'     => 'typo_setting',
        'default'     => [
            'font-family'    => '',
            'variant'        => '',
            'font-size'      => '',
            'line-height'    => '',
            'letter-spacing' => '0',
            'color'          => '',
        ],
        'priority'    => 10,
        'transport'   => 'auto',
        'output'      => [
            [
                'element' => 'h1',
            ],
        ],
    ];

    $fields[] = [
        'type'        => 'typography',
        'settings'    => 'typography_h2_setting',
        'label'       => esc_html__( 'Heading h2 Fonts', 'sixart' ),
        'section'     => 'typo_setting',
        'default'     => [
            'font-family'    => '',
            'variant'        => '',
            'font-size'      => '',
            'line-height'    => '',
            'letter-spacing' => '0',
            'color'          => '',
        ],
        'priority'    => 10,
        'transport'   => 'auto',
        'output'      => [
            [
                'element' => 'h2',
            ],
        ],
    ];

    $fields[] = [
        'type'        => 'typography',
        'settings'    => 'typography_h3_setting',
        'label'       => esc_html__( 'Heading h3 Fonts', 'sixart' ),
        'section'     => 'typo_setting',
        'default'     => [
            'font-family'    => '',
            'variant'        => '',
            'font-size'      => '',
            'line-height'    => '',
            'letter-spacing' => '0',
            'color'          => '',
        ],
        'priority'    => 10,
        'transport'   => 'auto',
        'output'      => [
            [
                'element' => 'h3',
            ],
        ],
    ];

    $fields[] = [
        'type'        => 'typography',
        'settings'    => 'typography_h4_setting',
        'label'       => esc_html__( 'Heading h4 Fonts', 'sixart' ),
        'section'     => 'typo_setting',
        'default'     => [
            'font-family'    => '',
            'variant'        => '',
            'font-size'      => '',
            'line-height'    => '',
            'letter-spacing' => '0',
            'color'          => '',
        ],
        'priority'    => 10,
        'transport'   => 'auto',
        'output'      => [
            [
                'element' => 'h4',
            ],
        ],
    ];

    $fields[] = [
        'type'        => 'typography',
        'settings'    => 'typography_h5_setting',
        'label'       => esc_html__( 'Heading h5 Fonts', 'sixart' ),
        'section'     => 'typo_setting',
        'default'     => [
            'font-family'    => '',
            'variant'        => '',
            'font-size'      => '',
            'line-height'    => '',
            'letter-spacing' => '0',
            'color'          => '',
        ],
        'priority'    => 10,
        'transport'   => 'auto',
        'output'      => [
            [
                'element' => 'h5',
            ],
        ],
    ];

    $fields[] = [
        'type'        => 'typography',
        'settings'    => 'typography_h6_setting',
        'label'       => esc_html__( 'Heading h6 Fonts', 'sixart' ),
        'section'     => 'typo_setting',
        'default'     => [
            'font-family'    => '',
            'variant'        => '',
            'font-size'      => '',
            'line-height'    => '',
            'letter-spacing' => '0',
            'color'          => '',
        ],
        'priority'    => 10,
        'transport'   => 'auto',
        'output'      => [
            [
                'element' => 'h6',
            ],
        ],
    ];
    return $fields;
}

add_filter( 'kirki/fields', 'sixart_typo_fields' );



/**
 * Added Fields
 */
function sixart_slug_setting( $fields ) {
    // slug settings
    $fields[] = [
        'type'     => 'text',
        'settings' => 'sixart_ev_slug',
        'label'    => esc_html__( 'Event Slug', 'sixart' ),
        'section'  => 'slug_setting',
        'default'  => esc_html__( 'ourevent', 'sixart' ),
        'priority' => 10,
    ];

    $fields[] = [
        'type'     => 'text',
        'settings' => 'sixart_port_slug',
        'label'    => esc_html__( 'Portfolio Slug', 'sixart' ),
        'section'  => 'slug_setting',
        'default'  => esc_html__( 'ourportfolio', 'sixart' ),
        'priority' => 10,
    ];

    return $fields;
}

add_filter( 'kirki/fields', 'sixart_slug_setting' );


/**
 * Added Fields
 */
if(class_exists( 'WooCommerce' )) {
function sixart_woo_setting( $fields ) {
    // woo settings
    $fields[] = [
        'type'     => 'text',
        'settings' => 'sixart_product_pp',
        'label'    => esc_html__( 'Product Per Page', 'sixart' ),
        'section'  => 'woo_setting',
        'default'  => esc_html__( '8', 'sixart' ),
        'priority' => 10,
    ];

    return $fields;
}

add_filter( 'kirki/fields', 'sixart_woo_setting' );
}

/**
 * This is a short hand function for getting setting value from customizer
 *
 * @param string $name
 *
 * @return bool|string
 */
function sixart_THEME_option( $name ) {
    $value = '';
    if ( class_exists( 'sixart' ) ) {
        $value = Kirki::get_option( sixart_get_theme(), $name );
    }

    return apply_filters( 'sixart_THEME_option', $value, $name );
}

/**
 * Get config ID
 *
 * @return string
 */
function sixart_get_theme() {
    return 'sixart';
}
