<?php
/**
 * The header for our theme
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package sixart
 */
?>

<!doctype html>
<html <?php language_attributes();?>>
<head>
	<meta charset="<?php bloginfo( 'charset' );?>">
    <?php if ( is_singular() && pings_open( get_queried_object() ) ): ?>
    <?php endif;?>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="profile" href="https://gmpg.org/xfn/11">
	<?php wp_head();?>
</head>

<body <?php body_class();?>>

    <?php wp_body_open();?>


    <?php
        $sixart_preloader = get_theme_mod( 'sixart_preloader', true );
    ?>

    <?php if ( !empty( $sixart_preloader ) ): ?>
      <div id="preloader">
         <div class="preloader">
               <span></span>
               <span></span>
         </div>
      </div>
    <?php endif;?>

    
    <!-- header start -->
    <?php do_action( 'sixart_header_style' );?>
    <!-- header end -->
    
    <!-- wrapper-box start -->
    <?php do_action( 'sixart_before_main_content' );?>