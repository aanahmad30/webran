<?php

/**
 * Template part for displaying post btn
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package sixart
 */

$sixart_blog_btn = get_theme_mod( 'sixart_blog_btn', 'Read More' );
$sixart_blog_btn_switch = get_theme_mod( 'sixart_blog_btn_switch', true );

?>

<?php if ( !empty( $sixart_blog_btn_switch ) ): ?>
<div class="post__button">
    <a class="tp-btn-sm" href="<?php the_permalink();?>"> <?php print esc_html( $sixart_blog_btn );?></a>
</div>
<?php endif;?>


