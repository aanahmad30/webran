<?php 

	/**
	 * Template part for displaying header layout three
	 *
	 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
	 *
	 * @package sixart
	*/

   // info
   $sixart_topbar_switch = get_theme_mod( 'sixart_topbar_switch', false );
   $sixart_phone_num = get_theme_mod( 'sixart_phone_num', __( '+(088) 234 567 899', 'sixart' ) );
   $sixart_mail_id = get_theme_mod( 'sixart_mail_id', __( 'info@sixart.com', 'sixart' ) );
   $sixart_address = get_theme_mod( 'sixart_address', __( 'Moon ave, New York, 2020 NY US', 'sixart' ) );
   $sixart_address_url = get_theme_mod( 'sixart_address_url', __( 'https://goo.gl/maps/qzqY2PAcQwUz1BYN9', 'sixart' ) );

   // contact button
   $sixart_button_text = get_theme_mod( 'sixart_button_text', __( 'Contact Us', 'sixart' ) );
   $sixart_button_link = get_theme_mod( 'sixart_button_link', __( '#', 'sixart' ) );

   // acc button
   $sixart_acc_button_text = get_theme_mod( 'sixart_acc_button_text', __( 'Login', 'sixart' ) );
   $sixart_acc_button_link = get_theme_mod( 'sixart_acc_button_link', __( '#', 'sixart' ) );

   // header right
   $sixart_search = get_theme_mod( 'sixart_search', false );
   $sixart_header_right = get_theme_mod( 'sixart_header_right', false );
   $sixart_menu_col = $sixart_header_right ? 'col-xxl-7 col-xl-7 col-lg-8 d-none d-lg-block' : 'col-xxl-10 col-xl-10 col-lg-9 d-none d-lg-block text-end';

?>


<header>
    <!-- tp-header-area-start -->
    <div id="header-sticky" class="tp-header-area tp-md-space header-three header-transparent z-index-5">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-xl-2 col-lg-3 col-6">
                    <div class="tp-logo">
                        <?php sixart_header_logo(); ?>
                    </div>
                </div>
                <div class="col-xl-8 col-lg-7 d-none d-lg-block">
                    <div class="tp-social-menu text-center">
                        <nav>
                            <?php sixart_header_social_profiles_2(); ?>
                        </nav>
                    </div>
                    <div class="tp-header-3-menu d-none">
                        <nav id="mobile-menu-2">
                           <?php sixart_header_menu();?>
                        </nav>
                    </div>
                </div>
                <?php if(!empty($sixart_header_right)) : ?>
                <div class="col-xl-2 col-lg-2 col-6">
                    <div class="header-right-three d-flex justify-content-end">
                        <button class="bars tp-menu-bar text-black"><i class="fal fa-bars"></i></button>
                    </div>
                </div>
                <?php endif; ?>

                <?php if(empty($sixart_header_right)) : ?>
                <div class="col-xl-2 col-lg-2 col-6">
                    <div class="header-right-three d-xl-none d-flex justify-content-end">
                        <button class="bars tp-menu-bar text-black"><i class="fal fa-bars"></i></button>
                    </div>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <!-- tp-header-area-end -->
</header>



<?php get_template_part( 'template-parts/header/header-side-info' ); ?>