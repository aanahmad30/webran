<?php 

	/**
	 * Template part for displaying header layout one
	 *
	 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
	 *
	 * @package sixart
	*/

	// info
    $sixart_mail_id = get_theme_mod( 'sixart_mail_id', __( 'info@educal.com', 'sixart' ) );
    $sixart_address = get_theme_mod( 'sixart_address', __( 'Moon ave, New York, 2020 NY US', 'sixart' ) );
    $sixart_address_url = get_theme_mod( 'sixart_address_url', __( 'https://goo.gl/maps/qzqY2PAcQwUz1BYN9', 'sixart' ) );

    // contact button
	 $sixart_button_text = get_theme_mod( 'sixart_button_text', __( 'Contact Us', 'sixart' ) );
    $sixart_button_link = get_theme_mod( 'sixart_button_link', __( '#', 'sixart' ) );

    // acc button
	 $sixart_acc_button_text = get_theme_mod( 'sixart_acc_button_text', __( 'Login', 'sixart' ) );
    $sixart_acc_button_link = get_theme_mod( 'sixart_acc_button_link', __( '#', 'sixart' ) );

    // header right
    $sixart_header_right = get_theme_mod( 'sixart_header_right', false );
    $sixart_search = get_theme_mod( 'sixart_search', false );
    $sixart_mini_cart = get_theme_mod( 'sixart_mini_cart', false );
    $sixart_side_hide = get_theme_mod( 'sixart_side_hide', false );
    $sixart_menu_col = $sixart_header_right ? 'col-xxl-7 col-xl-7 col-lg-8 d-none d-lg-block' : 'col-xxl-10 col-xl-10 col-lg-9 d-none d-lg-block text-end';

?>

<header>
    <!-- tp-header-area-start -->
    <div id="header-sticky" class="tp-header-area header-pl-pr header-transparent header-border-bottom">
        <div class="container-fluid">
            <div class="row g-0 align-items-center">
                <div class="col-xl-2 col-lg-2 col-md-4 col-6">
                    <div class="tp-logo tp-logo-border">
                        <?php sixart_header_logo(); ?>
                    </div>
                </div>
                <div class="col-xl-10 col-lg-10 col-md-8 col-6 d-flex justify-content-end">
                    <div class="tp-main-menu d-none d-xl-block">
                        <nav id="mobile-menu">
                           <?php sixart_header_menu();?>
                        </nav>
                    </div>
                    <div class="tp-header-right">
                        <?php if(!empty($sixart_header_right)) : ?>
                        <ul>
                           <?php if(!empty($sixart_search)) : ?>
                            <li class=" d-none d-md-inline-block search-wrapper">
                                <a class="tp-search-box" href="javascript:void(0)"><i
                                        class="tp-search-toggle fal fa-search"></i><i
                                        class="search-close  far fa-times"></i></a>
                                <?php sixart_search_form(); ?>
                            </li>
                            <?php endif; ?>

                            <?php if(!empty($sixart_mini_cart) && class_exists( 'WooCommerce' )) : ?>
                            <li class="d-none d-md-inline-block ede-shop-cart">
                                <a href="<?php echo wc_get_cart_url(); ?>"><i class="fal fa-shopping-basket"></i><span id="tp-cart-item" class="cart__count"><?php echo esc_html(WC()->cart->cart_contents_count); ?></span></a>
                                <div class="mini_shopping_cart_box"><?php woocommerce_mini_cart(); ?></div>
                            </li>
                            <?php endif; ?>
                            <li><a class="tp-menu-bar" href="javascript:void(0)"><i class="fas fa-bars"></i></a></li>
                        </ul>
                        <?php endif; ?>

                        
                        <?php if(empty($sixart_header_right)) : ?>
                        <ul class="d-xl-none">
                            <li><a class="tp-menu-bar" href="javascript:void(0)"><i class="fas fa-bars"></i></a></li>
                        </ul>
                        <?php endif; ?>

                        <!-- <ul>
                            <li><a class="tp-menu-bar" href="javascript:void(0)"><i class="fas fa-bars"></i></a></li>
                        </ul> -->
                        
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- tp-header-area-end -->
</header>


<?php get_template_part( 'template-parts/header/header-side-info' ); ?>