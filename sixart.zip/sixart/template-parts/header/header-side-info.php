<?php 

   /**
    * Template part for displaying header side information
    *
    * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
    *
    * @package sixart
   */

    $sixart_side_hide = get_theme_mod( 'sixart_side_hide', false );
    $sixart_search = get_theme_mod( 'sixart_search', false );
    $sixart_side_logo = get_theme_mod( 'sixart_side_logo', get_template_directory_uri() . '/assets/img/logo/logo-white.png' );
    $sixart_extra_about_text = get_theme_mod( 'sixart_extra_about_text', __( 'But I must explain to you how all this mistaken idea of denouncing pleasure and praising pain was born and will give you a complete account of the system and expound the actual teachings of the great explore', 'sixart' ) );

    $sixart_extra_map = get_theme_mod( 'sixart_extra_map', __( '#', 'sixart' ) );
    $sixart_contact_title = get_theme_mod( 'sixart_contact_title', __( 'Contact Info', 'sixart' ) );
    $sixart_extra_address = get_theme_mod( 'sixart_extra_address', __( '12/A, Mirnada City Tower, NYC', 'sixart' ) );
    $sixart_extra_phone = get_theme_mod( 'sixart_extra_phone', __( '088889797697', 'sixart' ) );
    $sixart_extra_email = get_theme_mod( 'sixart_extra_email', __( 'support@mail.com ', 'sixart' ) );

    $margin_class =  $sixart_side_hide ? '' : "mb-30" ;
?>

<div class="tp-offcanvas-area">
    <div class="tpoffcanvas">

        <div class="tpoffcanvas__close-btn <?php echo esc_attr($margin_class); ?>">
            <button class="close-btn"><i class="fal fa-times"></i></button>
        </div>

         <?php if ( !empty( $sixart_side_logo ) ): ?>
         <div class="tpoffcanvas__logo pt-50">
            <a href="<?php print esc_url( home_url( '/' ) );?>">
               <img src="<?php print esc_url($sixart_side_logo); ?>" alt="<?php print esc_attr__( 'logo', 'sixart' );?>">
            </a>
         </div>
         <?php endif;?>

         <?php if(!empty($sixart_extra_about_text)) : ?>
        <div class="tpoffcanvas__text">
            <p><?php echo sixart_kses($sixart_extra_about_text); ?></p>
        </div>
        <?php endif; ?>

        <div class="mobile-menu"></div>

        <?php if(!empty($sixart_side_hide)) : ?>
        <div class="tpoffcanvas__info">
            <?php if(!empty($sixart_contact_title)) : ?>
            <h3 class="offcanva-title"><?php echo sixart_kses($sixart_contact_title); ?></h3>
            <?php endif; ?>

            <?php if(!empty($sixart_extra_email)) : ?>
            <div class="tp-info-wrapper mb-20 d-flex align-items-center">
                <div class="tpoffcanvas__info-icon">
                  <i class="fal fa-envelope"></i>
                </div>
                <div class="tpoffcanvas__info-address">
                    <span><?php echo esc_html__('Email', 'sixart'); ?></span>
                    <p class="text-white m-0"><?php echo sixart_kses($sixart_extra_email); ?></p>
                </div>
            </div>
            <?php endif; ?>

            <?php if(!empty($sixart_extra_phone)) : ?>
            <div class="tp-info-wrapper mb-20 d-flex align-items-center">
                <div class="tpoffcanvas__info-icon">
                  <i class="fal fa-phone-alt"></i>
                </div>
                <div class="tpoffcanvas__info-address">
                    <span><?php echo esc_html__('Phone', 'sixart'); ?></span>
                    <p class="text-white m-0"><?php echo sixart_kses($sixart_extra_phone); ?></p>
                </div>
            </div>
            <?php endif; ?>

            <?php if(!empty($sixart_extra_address)) : ?>
            <div class="tp-info-wrapper mb-20 d-flex align-items-center">
                <div class="tpoffcanvas__info-icon">
                  <i class="fas fa-map-marker-alt"></i>
                </div>
                <div class="tpoffcanvas__info-address">
                    <span><?php echo esc_html__('Location', 'sixart'); ?></span>
                    <p class="text-white m-0"><?php echo sixart_kses($sixart_extra_address); ?></p>
                </div>
            </div>
            <?php endif; ?>
        </div>
        <?php sixart_header_social_profiles(); ?>
        <?php endif; ?>

    </div>
</div>

<div class="body-overlay"></div>

