<?php 

/**
 * Template part for displaying footer layout two
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package sixart
*/

$footer_c_form_switch = get_theme_mod( 'footer_c_form_switch', false );
$footer_c_title = get_theme_mod( 'footer_c_title', __('Get latest updates', 'sixart') );
$footer_c_shortcode = get_theme_mod( 'footer_c_shortcode', __('[shortcode here]', 'sixart') );
$sixart_copyright_link = get_theme_mod( 'sixart_copyright_link' );
$sixart_backtotop = get_theme_mod( 'sixart_backtotop', false );

$footer_bg_img = get_theme_mod( 'sixart_footer_bg' );
$sixart_footer_bg_url_from_page = function_exists( 'get_field' ) ? get_field( 'sixart_footer_bg' ) : '';
$sixart_footer_bg_color_from_page = function_exists( 'get_field' ) ? get_field( 'sixart_footer_bg_color' ) : '';
$footer_bg_color = get_theme_mod( 'sixart_footer_bg_color', '#151718' );
$sixart_footer_bottom_color = get_theme_mod( 'sixart_footer_bottom_color', '#151718' );
$bg_img = !empty( $sixart_footer_bg_url_from_page['url'] ) ? $sixart_footer_bg_url_from_page['url'] : $footer_bg_img;
$bg_color = !empty( $sixart_footer_bg_color_from_page ) ? $sixart_footer_bg_color_from_page : $footer_bg_color;
$footer_bg = !empty($bg_img) ? "background: url($bg_img)" : "background: $bg_color";

$footer_columns = 0;
$footer_widgets = get_theme_mod( 'footer_widget_number', 6 );

for ( $num = 1; $num <= $footer_widgets + 1; $num++ ) {
    if ( is_active_sidebar( 'footer-2-' . $num ) ) {
        $footer_columns++;
    }
}

switch ( $footer_columns ) {
case '1':
    $footer_class[1] = 'col-lg-12';
    break;
case '2':
    $footer_class[1] = 'col-lg-6 col-md-6';
    $footer_class[2] = 'col-lg-6 col-md-6';
    break;
case '3':
    $footer_class[1] = 'col-xl-4 col-lg-6 col-md-5';
    $footer_class[2] = 'col-xl-4 col-lg-6 col-md-7';
    $footer_class[3] = 'col-xl-4 col-lg-6';
    break;
case '4':
    $footer_class[1] = 'col-xxl-4 col-xl-4 col-lg-4 col-md-6 col-sm-7';
    $footer_class[2] = 'col-xxl-2 col-xl-2 col-lg-2 col-md-3 col-sm-5';
    $footer_class[3] = 'col-xxl-2 col-xl-2 col-lg-2 col-md-3 col-sm-5';
    $footer_class[4] = 'col-xxl-4 col-xl-4 col-lg-4 col-md-6 col-sm-7';
    break;
case '5':
    $footer_class[1] = 'col-xl-2 col-lg-2 col-md-3 col-6 mb-30';
    $footer_class[2] = 'col-xl-3 col-lg-2 col-md-3 col-6 mb-30';
    $footer_class[3] = 'col-xl-2 col-lg-2 col-md-3 col-6 mb-30';
    $footer_class[4] = 'col-xl-2 col-lg-2 col-md-3 col-6 mb-30';
    $footer_class[5] = 'col-xl-3 col-lg-4 col-md-6 col-12 mb-30';
    break;
default:
    $footer_class = 'col-xl-3 col-lg-3 col-md-6';
    break;
}

?>
<?php sixart_footer_social_profiles(); ?>
<footer>
    <!-- tp-footer-area-start -->
    <div class="tp-footer-area footer-bg pt-130" style="<?php echo esc_attr($footer_bg);?>">
        <div class="container">
            <?php if ( is_active_sidebar( 'footer-2-1' ) OR is_active_sidebar( 'footer-2-2' ) OR is_active_sidebar( 'footer-2-3' ) OR is_active_sidebar( 'footer-2-4' ) OR is_active_sidebar( 'footer-2-5' ) ): ?>
            <div class="row">
                <?php
                if ( $footer_columns < 4 ) {
                print '<div class="col-xl-2 col-lg-2 col-md-3 col-6 mb-30">';
                dynamic_sidebar( 'footer-2-1' );
                print '</div>';

                print '<div class="col-xl-3 col-lg-2 col-md-3 col-6 mb-30">';
                dynamic_sidebar( 'footer-2-2' );
                print '</div>';

                print '<div class="col-xl-2 col-lg-2 col-md-3 col-6 mb-30">';
                dynamic_sidebar( 'footer-2-3' );
                print '</div>';

                print '<div class="col-xl-2 col-lg-2 col-md-3 col-6 mb-30">';
                dynamic_sidebar( 'footer-2-4' );
                print '</div>';

                print '<div class="col-xl-3 col-lg-4 col-md-6 col-12 mb-30">';
                dynamic_sidebar( 'footer-2-5' );
                print '</div>';
                } else {
                    for ( $num = 1; $num <= $footer_columns; $num++ ) {
                        if ( !is_active_sidebar( 'footer-2-' . $num ) ) {
                            continue;
                        }
                        print '<div class="' . esc_attr( $footer_class[$num] ) . '">';
                        dynamic_sidebar( 'footer-2-' . $num );
                        print '</div>';
                    }
                }
                ?>
            </div>
            <?php endif; ?>
            <?php if(!empty($footer_c_form_switch)) : ?>
            <div class="row">
                <div class="col-12">
                    <div class="tp-newsletter-wrapper z-index-3">
                        <div class="row align-items-center">
                            <div class="col-lg-6 col-md-12 col-12">
                                <div class="tp-newsletter">
                                    <?php if(!empty($footer_c_title)) : ?>
                                    <div class="tp-newsletter__title">
                                        <h4 class="tp-newsletter-title"><?php echo sixart_kses($footer_c_title); ?></h4>
                                    </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="col-lg-6 col-md-12 col-12">
                                <div class="tp-newsletter">
                                    <div class="tp-newsletter__input p-relative">
                                        <?php if(!empty($footer_c_shortcode)) : ?>
                                            <?php echo do_shortcode($footer_c_shortcode); ?>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php endif; ?>
            <div class="copy-right-wrapper z-index-3">
                <div class="row">
                    <div class="col-xl-6 col-lg-7 col-12">
                        <div class="copyright-left text-center text-lg-start">
                            <p><?php print sixart_copyright_text(); ?></p>
                        </div>
                    </div>
                    <div class="col-xl-6 col-lg-5 col-12">
                        <?php if(!empty($sixart_copyright_link)) : ?>
                        <div class="copyright-right-side text-center text-lg-end">
                            <?php echo sixart_kses($sixart_copyright_link); ?>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- tp-footer-area-end -->

    <?php if(!empty($sixart_backtotop)) : ?>
    <button class="scroll-top scroll-to-target" data-target="html">
        <i class="far fa-angle-double-up"></i>
    </button>
    <?php endif; ?>


</footer>
